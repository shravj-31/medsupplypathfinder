"""Quick live check of the running API (does not create deliveries).

    python scripts/smoke_test.py            # API must be running on :8000
"""
import os
import sys

import requests

BASE = os.getenv("API_BASE_URL", "http://127.0.0.1:8000")
results = []


def check(name, cond, extra=""):
    results.append(bool(cond))
    print("%s  %s %s" % ("PASS" if cond else "FAIL", name, extra))


def call(method, path, **kw):
    r = requests.request(method, BASE + path, timeout=20, **kw)
    try:
        return r.status_code, r.json()
    except ValueError:
        return r.status_code, None


try:
    s, d = call("GET", "/api/health")
except requests.exceptions.RequestException:
    sys.exit("API not reachable at %s - start it first." % BASE)
check("health + database", s == 200 and d["database"] == "connected")

s, d = call("GET", "/api/robots/", params={"org_id": "ORG-001"})
check("robots list (ORG-001)", s == 200 and len(d) >= 5, "(%d units)" % len(d or []))

s, d = call("POST", "/api/routes/calculate", json={"source": "Pharmacy", "destination": "ICU", "algorithm": "dijkstra"})
check("Dijkstra Pharmacy->ICU = 60 m", s == 200 and d["distance_meters"] == 60)
s, d2 = call("POST", "/api/routes/calculate", json={"source": "Pharmacy", "destination": "ICU", "algorithm": "astar"})
check("A* matches Dijkstra", s == 200 and d2["distance_meters"] == 60)
s, d = call("POST", "/api/routes/calculate", json={"source": "Nowhere", "destination": "ICU"})
check("invalid location -> 404", s == 404)

s, _ = call("PUT", "/api/routes/edges/block", json={"source": "Elevator 1", "destination": "ICU", "blocked": True})
s2, d = call("POST", "/api/routes/calculate", json={"source": "Pharmacy", "destination": "ICU", "algorithm": "astar"})
check("blocked corridor -> alternative 70 m", s == 200 and s2 == 200 and d["distance_meters"] == 70)
call("PUT", "/api/routes/edges/block", json={"source": "Elevator 1", "destination": "ICU", "blocked": False})

s, d = call("POST", "/api/robo/preview", json={"org_id": "ORG-001", "weight_kg": 2, "source": "Blood Bank",
                                               "destination": "ICU", "priority": "Critical"})
check("decision matrix returns a winner", s == 200 and d["selected_robot"] is not None,
      "(winner %s)" % (d or {}).get("selected_robot"))
s, d = call("POST", "/api/robo/preview", json={"org_id": "ORG-001", "weight_kg": 14, "source": "Pharmacy",
                                               "destination": "ICU"})
check("wt > Capacity drops every unit", s == 200 and d["selected_robot"] is None and d["pool"]["capacity_ok"] == 0)

s, d = call("POST", "/api/fleet/robots", json={"org_id": "ORG-001", "robot_id": "SMK001", "load_capacity_kg": 4})
check("fleet add", s == 201)
s, d = call("DELETE", "/api/fleet/robots/SMK001")
check("fleet remove", s == 200)

s, d = call("POST", "/api/domains/refresh-names", json={"org_id": "ORG-001"})
check("domain names refresh", s == 200 and len(d["domains"]) == 3)

s, d = call("GET", "/api/robo/status")
mode = d["mode"]
s, _ = call("PUT", "/api/robo/mode", json={"mode": "auto"})
s2, _ = call("PUT", "/api/robo/mode", json={"mode": mode})
check("robo mode toggle", s == 200 and s2 == 200)

for ep in ("/api/organizations/", "/api/deliveries/", "/api/domains/", "/api/audit/", "/api/dashboard/summary"):
    s, _ = call("GET", ep)
    check("GET %s" % ep, s == 200)

print("\n%d/%d checks passed" % (sum(results), len(results)))
sys.exit(0 if all(results) else 1)
