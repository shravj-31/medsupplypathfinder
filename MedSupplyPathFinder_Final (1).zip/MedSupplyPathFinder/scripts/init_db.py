"""Create the database if needed, then (re)load sql/schema.sql.

    python scripts/init_db.py

WARNING: resets all project tables.  Run it before every demo for a clean start.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import psycopg                                       # noqa: E402
from backend.config import DB_CONFIG                 # noqa: E402


def main():
    cfg = dict(DB_CONFIG)
    dbname = cfg.pop("dbname")
    try:
        admin = psycopg.connect(dbname="postgres", autocommit=True, **cfg)
    except psycopg.Error as exc:
        sys.exit("Cannot connect to PostgreSQL at %s:%s as %s.\n%s\n"
                 "Check the values in .env and that the PostgreSQL service is running."
                 % (cfg["host"], cfg["port"], cfg["user"], exc))
    with admin:
        exists = admin.execute("SELECT 1 FROM pg_database WHERE datname = %s", (dbname,)).fetchone()
        if not exists:
            admin.execute('CREATE DATABASE "%s"' % dbname.replace('"', ""))
            print("Created database %s" % dbname)

    sql = (ROOT / "sql" / "schema.sql").read_text(encoding="utf-8")
    with psycopg.connect(dbname=dbname, **cfg) as conn:
        conn.execute(sql)
        counts = {t: conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
                  for t in ("organizations", "locations", "graph_edges", "domains", "robots",
                            "supplies", "deliveries")}
    print("Schema loaded into %s: %s" % (dbname, counts))
    print("Ready. Start the API:  python -m uvicorn backend.main:app --reload")


if __name__ == "__main__":
    main()
