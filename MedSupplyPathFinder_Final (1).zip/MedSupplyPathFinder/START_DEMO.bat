@echo off
REM ONE-CLICK DEMO: sets up (first time only), resets data, starts API + UI.
cd /d %~dp0
if not exist venv (
  echo First run: installing... this takes a few minutes.
  call setup.bat
)
if exist venv\Scripts\activate call venv\Scripts\activate
echo Resetting demo data...
python scripts\init_db.py
echo Starting API window...
start "Med-Supply API (keep open)" cmd /k "cd /d %~dp0 && call start_backend.bat"
timeout /t 8 /nobreak >nul
echo Starting UI window (browser opens at http://localhost:8501)...
start "Med-Supply UI (keep open)" cmd /k "cd /d %~dp0 && call start_frontend.bat"
timeout /t 6 /nobreak >nul
start http://localhost:8501
echo.
echo Backup if the UI fails: open docs\Showcase_Backup.html (works offline).
pause
