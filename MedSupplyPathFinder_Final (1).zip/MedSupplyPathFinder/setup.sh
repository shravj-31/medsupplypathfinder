#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
. venv/bin/activate
pip install --upgrade pip && pip install -r requirements.txt
python scripts/init_db.py
echo "Done. Run ./start_backend.sh and ./start_frontend.sh in two terminals."
