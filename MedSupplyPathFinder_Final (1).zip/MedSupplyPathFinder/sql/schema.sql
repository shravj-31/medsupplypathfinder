-- ============================================================
-- MED-SUPPLY PATHFINDER  v2  --  PostgreSQL schema + seed data
--
-- WARNING: this script RESETS the project tables (DROP + CREATE).
-- Run it once before the demo (scripts/init_db.py does it for you).
--
-- What is new in v2
--   * organizations      -> Organization Master (custom IDs, e.g. ORG-001)
--   * domains            -> Emergency / Medical / Dynamic (Set A) routing classes
--   * system_settings    -> Robo Mode (auto | manual) and tunables
--   * robots             -> org_id, robot_type, base_speed_mps, busy_until
--   * deliveries         -> weight_kg (wt), time estimate, schedule window
--   * robot_schedule     -> explicit per-robot timeline (reserved windows)
--   * audit_log          -> global timestamped action log (+ DB triggers)
-- ============================================================

DROP TABLE IF EXISTS audit_log, robot_schedule, deliveries, supplies,
    robots, domains, system_settings, graph_edges, locations,
    organizations CASCADE;
DROP FUNCTION IF EXISTS set_updated_at() CASCADE;
DROP FUNCTION IF EXISTS audit_state_change() CASCADE;

-- ------------------------------------------------------------
-- Helper functions / triggers
-- ------------------------------------------------------------
CREATE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ------------------------------------------------------------
-- 1. ORGANIZATION MASTER  (custom IDs)
-- ------------------------------------------------------------
CREATE TABLE organizations (
    org_id        VARCHAR(20) PRIMARY KEY
                  CHECK (org_id ~ '^[A-Za-z0-9_-]{3,20}$'),
    org_name      VARCHAR(100) NOT NULL UNIQUE,
    org_type      VARCHAR(50)  NOT NULL DEFAULT 'Hospital',
    contact_email VARCHAR(120),
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_org_updated BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------
-- 2. LOCATIONS + GRAPH EDGES  (hospital map, shared by all orgs)
-- ------------------------------------------------------------
CREATE TABLE locations (
    location_id   SERIAL PRIMARY KEY,
    location_name VARCHAR(100) UNIQUE NOT NULL,
    location_type VARCHAR(50)  NOT NULL,
    building_name VARCHAR(100),
    floor_number  INT,
    x_coordinate  DOUBLE PRECISION,
    y_coordinate  DOUBLE PRECISION,
    is_accessible BOOLEAN DEFAULT TRUE
);

CREATE TABLE graph_edges (
    edge_id              SERIAL PRIMARY KEY,
    source_location      INT NOT NULL REFERENCES locations(location_id),
    destination_location INT NOT NULL REFERENCES locations(location_id),
    distance_meters      DOUBLE PRECISION NOT NULL CHECK (distance_meters > 0),
    travel_time_seconds  INT CHECK (travel_time_seconds > 0),
    is_blocked           BOOLEAN DEFAULT FALSE,
    edge_type            VARCHAR(30) DEFAULT 'corridor',
    UNIQUE (source_location, destination_location)
);

-- ------------------------------------------------------------
-- 3. DOMAIN CONFIGURATIONS  (routing classes)
-- ------------------------------------------------------------
CREATE TABLE domains (
    domain_id          VARCHAR(20) PRIMARY KEY,
    routing_class      VARCHAR(20) NOT NULL
                       CHECK (routing_class IN ('Emergency','Medical','Dynamic')),
    domain_name        VARCHAR(120) NOT NULL,
    option_set         VARCHAR(20),
    config             JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    names_refreshed_at TIMESTAMPTZ,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_domains_updated BEFORE UPDATE ON domains
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------
-- 4. SYSTEM SETTINGS  (Robo Mode etc.)
-- ------------------------------------------------------------
CREATE TABLE system_settings (
    key        VARCHAR(50) PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 5. ROBOTS / DRONES  (the fleet)
--    Capacity     = load_capacity_kg
--    Availability = robot_status = 'Available' AND not reserved (busy_until)
-- ------------------------------------------------------------
CREATE TABLE robots (
    robot_id           VARCHAR(20) PRIMARY KEY,
    org_id             VARCHAR(20) NOT NULL
                       REFERENCES organizations(org_id) ON DELETE CASCADE,
    robot_type         VARCHAR(10) NOT NULL DEFAULT 'Robot'
                       CHECK (robot_type IN ('Robot','Drone')),
    battery_percentage INT NOT NULL CHECK (battery_percentage BETWEEN 0 AND 100),
    robot_status       VARCHAR(20) NOT NULL
                       CHECK (robot_status IN
                         ('Available','Active','Charging','Offline','Maintenance')),
    current_location   INT REFERENCES locations(location_id),
    load_capacity_kg   DOUBLE PRECISION NOT NULL CHECK (load_capacity_kg > 0),
    base_speed_mps     DOUBLE PRECISION NOT NULL DEFAULT 1.5
                       CHECK (base_speed_mps > 0),
    busy_until         TIMESTAMPTZ,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_robots_org ON robots(org_id);
CREATE TRIGGER trg_robots_updated BEFORE UPDATE ON robots
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------
-- 6. SUPPLIES
-- ------------------------------------------------------------
CREATE TABLE supplies (
    supply_id                VARCHAR(20) PRIMARY KEY,
    supply_name              VARCHAR(100) NOT NULL,
    supply_type              VARCHAR(50)  NOT NULL,
    quantity                 INT NOT NULL CHECK (quantity >= 0),
    unit                     VARCHAR(20) DEFAULT 'units',
    storage_location         INT REFERENCES locations(location_id),
    expiry_date              DATE,
    requires_urgent_delivery BOOLEAN DEFAULT FALSE
);

-- ------------------------------------------------------------
-- 7. DELIVERIES  (a "task request"; weight_kg is the input wt)
-- ------------------------------------------------------------
CREATE TABLE deliveries (
    delivery_id          VARCHAR(20) PRIMARY KEY,
    org_id               VARCHAR(20) NOT NULL
                         REFERENCES organizations(org_id) ON DELETE CASCADE,
    domain_id            VARCHAR(20) REFERENCES domains(domain_id) ON DELETE SET NULL,
    supply_id            VARCHAR(20) NOT NULL REFERENCES supplies(supply_id),
    source_location      INT NOT NULL REFERENCES locations(location_id),
    destination_location INT NOT NULL REFERENCES locations(location_id),
    assigned_robot       VARCHAR(20) REFERENCES robots(robot_id) ON DELETE SET NULL,
    quantity             INT NOT NULL CHECK (quantity > 0),
    weight_kg            DOUBLE PRECISION NOT NULL DEFAULT 1 CHECK (weight_kg > 0),
    priority             VARCHAR(20) NOT NULL
                         CHECK (priority IN ('Critical','High','Medium','Low')),
    delivery_status      VARCHAR(20) NOT NULL DEFAULT 'Pending'
                         CHECK (delivery_status IN
                           ('Pending','Assigned','In Transit','Delivered',
                            'Failed','Cancelled')),
    algorithm_used       VARCHAR(20)
                         CHECK (algorithm_used IN ('A*','Dijkstra')
                                OR algorithm_used IS NULL),
    route_distance_m     DOUBLE PRECISION,
    route_path           TEXT,
    est_duration_seconds DOUBLE PRECISION,
    scheduled_start      TIMESTAMPTZ,
    scheduled_end        TIMESTAMPTZ,
    schedule_mode        VARCHAR(10) CHECK (schedule_mode IN ('auto','manual')),
    schedule_note        TEXT,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    delivered_at         TIMESTAMPTZ,
    CHECK (source_location <> destination_location)
);
CREATE INDEX idx_deliveries_status ON deliveries(delivery_status);
CREATE TRIGGER trg_deliveries_updated BEFORE UPDATE ON deliveries
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------
-- 8. ROBOT SCHEDULE  (the unit's reserved timeline)
-- ------------------------------------------------------------
CREATE TABLE robot_schedule (
    schedule_id      SERIAL PRIMARY KEY,
    robot_id         VARCHAR(20) NOT NULL REFERENCES robots(robot_id) ON DELETE CASCADE,
    delivery_id      VARCHAR(20) NOT NULL REFERENCES deliveries(delivery_id) ON DELETE CASCADE,
    start_time       TIMESTAMPTZ NOT NULL,
    end_time         TIMESTAMPTZ NOT NULL,
    duration_seconds DOUBLE PRECISION NOT NULL,
    status           VARCHAR(12) NOT NULL DEFAULT 'Running'
                     CHECK (status IN ('Running','Completed','Cancelled')),
    mode             VARCHAR(10) NOT NULL DEFAULT 'auto'
                     CHECK (mode IN ('auto','manual')),
    details          JSONB NOT NULL DEFAULT '{}'::jsonb,
    CHECK (end_time >= start_time)
);
-- A unit can only have ONE running reservation at a time.
CREATE UNIQUE INDEX uq_one_running_per_robot
    ON robot_schedule(robot_id) WHERE status = 'Running';

-- ------------------------------------------------------------
-- 9. AUDIT LOG  (global timestamped action log)
-- ------------------------------------------------------------
CREATE TABLE audit_log (
    log_id      BIGSERIAL PRIMARY KEY,
    logged_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor       VARCHAR(50) NOT NULL DEFAULT 'system',
    entity_type VARCHAR(30) NOT NULL,
    entity_id   VARCHAR(50),
    action      VARCHAR(40) NOT NULL,
    details     JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX idx_audit_time ON audit_log(logged_at DESC);

-- Automatic audit of state changes, even for direct SQL updates.
CREATE FUNCTION audit_state_change() RETURNS trigger AS $$
BEGIN
    IF TG_TABLE_NAME = 'robots' THEN
        IF NEW.robot_status IS DISTINCT FROM OLD.robot_status THEN
            INSERT INTO audit_log (actor, entity_type, entity_id, action, details)
            VALUES ('database', 'robot', NEW.robot_id, 'STATUS_CHANGE',
                    jsonb_build_object('from', OLD.robot_status,
                                       'to', NEW.robot_status,
                                       'battery', NEW.battery_percentage));
        END IF;
    ELSIF TG_TABLE_NAME = 'deliveries' THEN
        IF NEW.delivery_status IS DISTINCT FROM OLD.delivery_status THEN
            INSERT INTO audit_log (actor, entity_type, entity_id, action, details)
            VALUES ('database', 'delivery', NEW.delivery_id, 'STATUS_CHANGE',
                    jsonb_build_object('from', OLD.delivery_status,
                                       'to', NEW.delivery_status,
                                       'robot', NEW.assigned_robot));
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_robots_audit AFTER UPDATE ON robots
    FOR EACH ROW EXECUTE FUNCTION audit_state_change();
CREATE TRIGGER trg_deliveries_audit AFTER UPDATE ON deliveries
    FOR EACH ROW EXECUTE FUNCTION audit_state_change();

-- ============================================================
-- SEED DATA
-- ============================================================

-- A. ORGANIZATIONS (custom IDs)
INSERT INTO organizations (org_id, org_name, org_type, contact_email) VALUES
    ('ORG-001', 'City General Hospital', 'Hospital', 'ops@citygeneral.example'),
    ('ORG-002', 'Metro Care Clinic',     'Clinic',   'ops@metrocare.example');

-- B. LOCATIONS
INSERT INTO locations
    (location_name, location_type, building_name, floor_number, x_coordinate, y_coordinate)
VALUES
    ('Pharmacy',       'Pharmacy',          'Main Block',       1, 10, 10),
    ('Blood Bank',     'Blood Bank',        'Main Block',       1, 10, 50),
    ('Ward A',         'Ward',              'Main Block',       1, 60, 10),
    ('ICU',            'ICU',               'Emergency Block',  2, 80, 20),
    ('Laboratory',     'Laboratory',        'Diagnostic Block', 1, 90, 60),
    ('Surgery',        'Operation Theatre', 'Surgery Block',    2, 60, 70),
    ('Elevator 1',     'Elevator',          'Main Block',       1, 40, 20),
    ('Emergency Dock', 'Robot Dock',        'Emergency Block',  1, 70, 30);

-- C. GRAPH EDGES (forward, then mirrored so corridors are bidirectional)
INSERT INTO graph_edges
    (source_location, destination_location, distance_meters, travel_time_seconds, edge_type)
SELECT s.location_id, d.location_id, e.dist, e.secs, e.etype
FROM (VALUES
    ('Pharmacy',       'Ward A',         50.0, 60, 'corridor'),
    ('Ward A',         'ICU',            20.0, 30, 'corridor'),
    ('ICU',            'Laboratory',     30.0, 45, 'corridor'),
    ('Pharmacy',       'Elevator 1',     35.0, 45, 'corridor'),
    ('Elevator 1',     'ICU',            25.0, 35, 'elevator'),
    ('Blood Bank',     'Surgery',        40.0, 50, 'corridor'),
    ('Surgery',        'ICU',            35.0, 45, 'corridor'),
    ('Ward A',         'Surgery',        65.0, 80, 'corridor'),
    ('Pharmacy',       'Blood Bank',     45.0, 55, 'corridor'),
    ('ICU',            'Emergency Dock', 15.0, 20, 'corridor'),
    ('Emergency Dock', 'Surgery',        30.0, 40, 'corridor'),
    ('Laboratory',     'Surgery',        25.0, 35, 'corridor')
) AS e(src, dst, dist, secs, etype)
JOIN locations s ON s.location_name = e.src
JOIN locations d ON d.location_name = e.dst;

INSERT INTO graph_edges
    (source_location, destination_location, distance_meters, travel_time_seconds, edge_type)
SELECT destination_location, source_location, distance_meters, travel_time_seconds, edge_type
FROM graph_edges
ON CONFLICT (source_location, destination_location) DO NOTHING;

-- D. DOMAINS (Emergency / Medical / Dynamic "Set A")
INSERT INTO domains (domain_id, routing_class, domain_name, option_set, config) VALUES
    ('DOM-EMG', 'Emergency', 'Emergency Domain',        NULL,
     '{"speed_multiplier": 1.25, "min_battery": 15,
       "name_template": "{org} - Emergency Domain"}'::jsonb),
    ('DOM-MED', 'Medical',   'Medical Domain',          NULL,
     '{"speed_multiplier": 1.0, "min_battery": 30,
       "name_template": "{org} - Medical Domain"}'::jsonb),
    ('DOM-DYN', 'Dynamic',   'Dynamic Domain (Set A)',  'Set A',
     '{"speed_multiplier": 1.1, "min_battery": 20,
       "weights": {"eta": 0.5, "battery": 0.3, "utilisation": 0.2},
       "pressure_threshold": 3, "pressure_boost": 0.2,
       "name_template": "{org} - Dynamic Domain ({set})"}'::jsonb);

-- E. SYSTEM SETTINGS  (starts in MANUAL so the demo can flip to AUTO live)
INSERT INTO system_settings (key, value) VALUES
    ('robo_mode',             'manual'),
    ('auto_interval_seconds', '5'),
    ('payload_alpha',         '0.6'),
    ('handling_seconds',      '10'),
    ('battery_drain_per_m',   '0.05'),
    ('battery_reserve',       '10'),
    ('default_org',           'ORG-001');

-- F. FLEET  (Capacity in kg, base speed in m/s)
INSERT INTO robots
    (robot_id, org_id, robot_type, battery_percentage, robot_status,
     current_location, load_capacity_kg, base_speed_mps)
SELECT v.robot_id, v.org_id, v.rtype, v.battery, v.status,
       l.location_id, v.capacity, v.speed
FROM (VALUES
    ('RB001', 'ORG-001', 'Robot',  92, 'Available',   'Pharmacy',       10.0, 1.5),
    ('RB002', 'ORG-001', 'Robot',  65, 'Charging',    'Emergency Dock',  8.0, 1.4),
    ('RB003', 'ORG-001', 'Robot',  78, 'Available',   'Blood Bank',     12.0, 1.3),
    ('RB004', 'ORG-001', 'Robot',  25, 'Maintenance', 'Surgery',        10.0, 1.5),
    ('DR001', 'ORG-001', 'Drone',  88, 'Available',   'Emergency Dock',  3.0, 4.0),
    ('RB101', 'ORG-002', 'Robot',  95, 'Available',   'Pharmacy',        6.0, 1.5),
    ('RB102', 'ORG-002', 'Robot',  80, 'Available',   'Ward A',         15.0, 1.2)
) AS v(robot_id, org_id, rtype, battery, status, loc, capacity, speed)
JOIN locations l ON l.location_name = v.loc;

-- G. SUPPLIES
INSERT INTO supplies
    (supply_id, supply_name, supply_type, quantity, unit,
     storage_location, expiry_date, requires_urgent_delivery)
SELECT v.supply_id, v.supply_name, v.supply_type, v.quantity, v.unit,
       l.location_id, v.expiry::DATE, v.urgent
FROM (VALUES
    ('SUP001', 'Packed Red Blood Cells', 'Blood',        20,  'units',     'Blood Bank',     '2026-12-31', TRUE),
    ('SUP002', 'Emergency Medicine Kit', 'Medicine',     50,  'kits',      'Pharmacy',       '2027-06-30', TRUE),
    ('SUP003', 'Vaccine Pack',           'Vaccine',      100, 'doses',     'Pharmacy',       '2027-03-31', FALSE),
    ('SUP004', 'Laboratory Sample Kit',  'Lab Sample',   30,  'kits',      'Laboratory',     '2027-01-31', TRUE),
    ('SUP005', 'Surgical Kit',           'Surgical Kit', 25,  'kits',      'Pharmacy',       '2027-08-31', FALSE),
    ('SUP006', 'Oxygen Cylinder',        'Oxygen',       10,  'cylinders', 'Emergency Dock', '2027-12-31', TRUE)
) AS v(supply_id, supply_name, supply_type, quantity, unit, loc, expiry, urgent)
JOIN locations l ON l.location_name = v.loc;

-- H. DELIVERY REQUESTS (wt = weight_kg). All start Pending.
--    DEL005 (14 kg) exceeds every ORG-001 unit's capacity on purpose:
--    it demonstrates the wt <= Capacity check.
INSERT INTO deliveries
    (delivery_id, org_id, domain_id, supply_id, source_location,
     destination_location, quantity, weight_kg, priority)
SELECT v.delivery_id, 'ORG-001', v.domain_id, v.supply_id,
       src.location_id, dst.location_id, v.quantity, v.wt, v.priority
FROM (VALUES
    ('DEL001', 'DOM-EMG', 'SUP001', 'Blood Bank',     'ICU',     2,  2.0, 'Critical'),
    ('DEL002', 'DOM-MED', 'SUP002', 'Pharmacy',       'ICU',     1,  1.5, 'High'),
    ('DEL003', 'DOM-MED', 'SUP005', 'Pharmacy',       'Surgery', 2,  6.0, 'Medium'),
    ('DEL004', 'DOM-DYN', 'SUP004', 'Laboratory',     'Ward A',  1,  0.8, 'High'),
    ('DEL005', 'DOM-MED', 'SUP006', 'Emergency Dock', 'Surgery', 1, 14.0, 'Medium')
) AS v(delivery_id, domain_id, supply_id, src_name, dst_name, quantity, wt, priority)
JOIN locations src ON src.location_name = v.src_name
JOIN locations dst ON dst.location_name = v.dst_name;

INSERT INTO audit_log (actor, entity_type, entity_id, action, details)
VALUES ('system', 'system', 'schema', 'DB_INITIALISED',
        '{"note": "schema v2 created and seeded"}'::jsonb);

-- Quick verification
SELECT 'organizations' AS tbl, COUNT(*) FROM organizations
UNION ALL SELECT 'locations',   COUNT(*) FROM locations
UNION ALL SELECT 'graph_edges', COUNT(*) FROM graph_edges
UNION ALL SELECT 'domains',     COUNT(*) FROM domains
UNION ALL SELECT 'robots',      COUNT(*) FROM robots
UNION ALL SELECT 'supplies',    COUNT(*) FROM supplies
UNION ALL SELECT 'deliveries',  COUNT(*) FROM deliveries;
