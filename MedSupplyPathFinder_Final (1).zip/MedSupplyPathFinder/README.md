# Med-Supply PathFinder (v2)

Hospital medical-supply delivery with **route optimisation (Dijkstra / A\*)**, a **multi-attribute fleet
allocation engine (decision matrix)** and **Robo Mode** (automatic vs manual scheduling).

```
Streamlit UI  ->  FastAPI  ->  psycopg  ->  PostgreSQL
(frontend/)      (backend/)               (sql/schema.sql)
```

## Fastest start (Windows)

Double-click **`START_DEMO.bat`**. It installs (first time), resets the data, starts the API and the UI and opens the browser.
Backup if anything fails: open `docs/Showcase_Backup.html` (works offline, no install).

## Quick start (step by step, Windows)

1. Install Python 3.10+ and PostgreSQL. Edit `.env` if your DB password is not `123`.
2. Double-click **`setup.bat`** (creates `venv`, installs packages, builds + seeds the database).
3. Double-click **`start_backend.bat`**  -> API at http://127.0.0.1:8000  (Swagger: `/docs`)
4. Double-click **`start_frontend.bat`** -> UI at http://localhost:8501
5. Before every demo: **`reset_demo.bat`** (restores the clean seed data).

Linux/macOS: `./setup.sh`, `./start_backend.sh`, `./start_frontend.sh`.

Manual alternative:
```
python -m venv venv && venv\Scripts\activate
pip install -r requirements.txt
python scripts/init_db.py
python -m uvicorn backend.main:app --reload        # terminal 1
python -m streamlit run frontend/app.py            # terminal 2
python scripts/smoke_test.py                       # optional live check (API running)
pytest                                             # unit tests (+ API tests when the DB is loaded)
```

## How allocation works (the decision matrix)

| Input | Meaning | Source |
|---|---|---|
| `wt` | payload weight of the task (kg) | task request (`deliveries.weight_kg`) |
| `Capacity` | max load a unit can carry | `robots.load_capacity_kg` |
| `Availability` | free / busy / charging / offline | `robot_status` + `busy_until` |
| `No. of Robots` | pooled units in the organization | `COUNT(robots)` per `org_id` |

Pipeline (`backend/services/engine.py`, pure Python, unit-tested):

1. **Availability filter** - busy / Charging / Offline / Maintenance units are dropped.
2. **Capacity check** `wt <= Capacity` - otherwise the unit is dropped from the pool for that task.
3. **Domain battery floor** - Emergency 15 %, Medical 30 %, Dynamic 20 %.
4. **Route** - A\* on the live hospital graph (blocked corridors excluded).
5. **Time estimation**
   `speed = base_speed x domain multiplier`
   `empty leg = d_pickup / speed`
   `loaded leg = d_delivery x (1 + 0.6 x wt / Capacity) / speed`   <- payload coefficient
   `total = empty leg + loaded leg + 10 s handling`
6. **Domain ranking** - Emergency: fastest ETA. Medical: `ETA x (1+utilisation) x battery penalty`.
   Dynamic (Set A): weighted, normalised ETA / battery / load, shifting to speed when the queue grows.
7. **Execution constraint** - the winner's window is written to `robot_schedule`, the unit becomes
   `Active` with `busy_until = end`. When the window elapses it is released, moved to the destination,
   its battery is reduced, and the delivery becomes `Delivered`.

## Checklist -> where it lives

| Requirement | Implementation |
|---|---|
| Organization Master (custom IDs) | `organizations` table, `/api/organizations`, UI *Organizations* |
| Timestamps / global action log | `audit_log` table + DB triggers + app logging, `/api/audit`, UI *Audit Log*; every table has `created_at` / `updated_at` |
| Fleet multi-tenancy (add/remove nodes) | `POST /api/fleet/robots`, `DELETE /api/fleet/robots/{id}`, `PUT` update; UI *Fleet* |
| Domains: Emergency, Medical, Dynamic (Set A) + refresh names | `backend/services/domains.py` (3 routing classes), `POST /api/domains/refresh-names`, UI *Domains* |
| Robo Mode dashboard (auto) | background loop in `backend/services/robo.py`, `PUT /api/robo/mode`, `POST /api/robo/run-cycle`; UI *Robo Mode* |
| Manual override route | `POST /api/robo/manual-schedule`; UI *Robo Mode -> Manual override* |
| wt / Capacity / Availability / No. of Robots | `engine.py`, `POST /api/robo/preview`; UI *Decision Matrix* |

## Project layout
```
backend/     main.py, routers/ (HTTP), services/ (engine, scheduler, domains, fleet, robo, ...)
algorithms/  graph.py, dijkstra.py, astar.py
frontend/    app.py (Streamlit), api.py (HTTP client)
sql/         schema.sql (schema + seed; resets tables)
scripts/     init_db.py, smoke_test.py
tests/       test_algorithms.py, test_engine.py, test_api.py
docs/        PRESENTATION_GUIDE.md
```

## Notes
* Pharmacy -> ICU is **60 m** via Elevator 1 in this dataset. The 70 m route (Pharmacy -> Ward A -> ICU)
  appears when the elevator corridor is blocked - used as the "alternative route" demo.
* The A\* heuristic is the Euclidean distance scaled by the smallest (edge length / straight line) ratio,
  which keeps it admissible, so A\* always returns Dijkstra's optimal distance.
* Time is simulated against the real clock: a 54 s task really holds the unit for 54 s.
  "Complete now" (Deliveries page) fast-forwards a running task for demos.
* The hospital map is shared by all organizations; fleets, deliveries and settings are per organization.
