"""Thin psycopg 3 helpers.  Every call opens a short-lived connection."""
import contextlib

import psycopg
from psycopg.rows import dict_row

from backend.config import DB_CONFIG


def connect():
    return psycopg.connect(**DB_CONFIG, row_factory=dict_row)


@contextlib.contextmanager
def transaction():
    """Yield a connection; commit on success, roll back on any error."""
    conn = connect()
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_all(sql, params=None):
    with transaction() as conn:
        return conn.execute(sql, params).fetchall()


def fetch_one(sql, params=None):
    with transaction() as conn:
        return conn.execute(sql, params).fetchone()


def execute(sql, params=None):
    with transaction() as conn:
        conn.execute(sql, params)
