"""Med-Supply PathFinder API.   Run:  uvicorn backend.main:app --reload"""
import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from backend.errors import AppError
from backend.routers import (audit, deliveries, domains, fleet, organizations,
                             robo, routes, system)
from backend.services import robo as robo_service


@asynccontextmanager
async def lifespan(app):
    task = asyncio.create_task(robo_service.loop())     # Robo Mode background scheduler
    try:
        yield
    finally:
        task.cancel()


app = FastAPI(title="Med-Supply PathFinder", version="2.0",
              description="Hospital supply delivery: routing, fleet allocation and Robo Mode.",
              lifespan=lifespan)


@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


for r in (system, organizations, fleet, deliveries, routes, domains, robo, audit):
    app.include_router(r.router, prefix="/api")


@app.get("/", include_in_schema=False)
def root():
    return {"app": "Med-Supply PathFinder", "docs": "/docs", "health": "/api/health"}
