"""Delivery (task request) service."""
from backend.database import fetch_all, fetch_one, transaction
from backend.errors import BadRequestError, NotFoundError
from backend.services import audit, settings
from backend.services.domains import default_domain_id, get_domain
from backend.services.routing import resolve_location

SELECT = (
    "SELECT d.delivery_id, d.org_id, d.domain_id, d.supply_id, sp.supply_name, "
    "src.location_name AS source, dst.location_name AS destination, "
    "d.assigned_robot, d.quantity, d.weight_kg, d.priority, d.delivery_status, "
    "d.algorithm_used, d.route_distance_m, d.route_path, d.est_duration_seconds, "
    "d.scheduled_start, d.scheduled_end, d.schedule_mode, d.schedule_note, "
    "GREATEST(0, COALESCE(EXTRACT(EPOCH FROM (d.scheduled_end - now())), 0))::float8 AS seconds_remaining, "
    "d.created_at, d.updated_at, d.delivered_at "
    "FROM deliveries d "
    "JOIN supplies sp ON sp.supply_id = d.supply_id "
    "JOIN locations src ON src.location_id = d.source_location "
    "JOIN locations dst ON dst.location_id = d.destination_location ")

ORDER = ("ORDER BY CASE d.priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 "
         "WHEN 'Medium' THEN 3 ELSE 4 END, d.created_at, d.delivery_id")


def list_deliveries(org_id=None, status=None):
    sql, params = SELECT + "WHERE TRUE", []
    if org_id:
        sql += " AND d.org_id = %s"
        params.append(org_id)
    if status:
        sql += " AND d.delivery_status = %s"
        params.append(status)
    return fetch_all(sql + " " + ORDER, params)


def get_delivery(delivery_id):
    row = fetch_one(SELECT + "WHERE d.delivery_id = %s", (delivery_id,))
    if not row:
        raise NotFoundError("Delivery '%s' not found" % delivery_id)
    return row


def list_supplies():
    return fetch_all("SELECT s.supply_id, s.supply_name, s.supply_type, s.quantity, s.unit, "
                     "l.location_name AS storage_location, s.expiry_date, s.requires_urgent_delivery "
                     "FROM supplies s LEFT JOIN locations l ON l.location_id = s.storage_location "
                     "ORDER BY s.supply_id")


def create_delivery(supply_id, source, destination, weight_kg, quantity=1, priority="Medium",
                    org_id=None, domain_id=None, actor="operator"):
    with transaction() as conn:
        org_id = org_id or settings.get("default_org", "ORG-001")
        org = conn.execute("SELECT is_active FROM organizations WHERE org_id = %s", (org_id,)).fetchone()
        if not org:
            raise NotFoundError("Organization '%s' not found" % org_id)
        if not org["is_active"]:
            raise BadRequestError("Organization '%s' is inactive" % org_id)
        if not conn.execute("SELECT 1 FROM supplies WHERE supply_id = %s", (supply_id,)).fetchone():
            raise NotFoundError("Supply '%s' not found" % supply_id)
        s, d = resolve_location(conn, source), resolve_location(conn, destination)
        if s["location_id"] == d["location_id"]:
            raise BadRequestError("Source and destination must be different")
        domain_id = domain_id or default_domain_id(priority)
        get_domain(domain_id, conn)                     # validates it exists and is active
        row = conn.execute("SELECT COALESCE(MAX(SUBSTRING(delivery_id FROM 4)::int), 0) + 1 AS n "
                           "FROM deliveries WHERE delivery_id ~ '^DEL[0-9]+$'").fetchone()
        delivery_id = "DEL%03d" % row["n"]
        conn.execute(
            "INSERT INTO deliveries (delivery_id, org_id, domain_id, supply_id, source_location, "
            "destination_location, quantity, weight_kg, priority) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (delivery_id, org_id, domain_id, supply_id, s["location_id"], d["location_id"],
             quantity, weight_kg, priority))
        audit.log(conn, "delivery", delivery_id, "DELIVERY_CREATED",
                  {"org_id": org_id, "from": s["location_name"], "to": d["location_name"],
                   "weight_kg": weight_kg, "priority": priority, "domain": domain_id}, actor)
    return get_delivery(delivery_id)
