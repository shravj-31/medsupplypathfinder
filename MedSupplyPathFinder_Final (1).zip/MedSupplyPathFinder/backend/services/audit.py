"""Global timestamped action log (audit_log table)."""
import json

from backend.database import fetch_all, transaction


def log(conn, entity_type, entity_id, action, details=None, actor="system"):
    conn.execute(
        "INSERT INTO audit_log (actor, entity_type, entity_id, action, details) "
        "VALUES (%s, %s, %s, %s, %s::jsonb)",
        (actor, entity_type, str(entity_id), action,
         json.dumps(details or {}, default=str)),
    )


def log_standalone(entity_type, entity_id, action, details=None, actor="system"):
    with transaction() as conn:
        log(conn, entity_type, entity_id, action, details, actor)


def list_logs(limit=100, entity_type=None, action=None, entity_id=None):
    sql = ("SELECT log_id, logged_at, actor, entity_type, entity_id, action, details "
           "FROM audit_log WHERE TRUE")
    params = []
    if entity_type:
        sql += " AND entity_type = %s"
        params.append(entity_type)
    if action:
        sql += " AND action = %s"
        params.append(action)
    if entity_id:
        sql += " AND entity_id = %s"
        params.append(entity_id)
    sql += " ORDER BY logged_at DESC, log_id DESC LIMIT %s"
    params.append(int(limit))
    return fetch_all(sql, params)
