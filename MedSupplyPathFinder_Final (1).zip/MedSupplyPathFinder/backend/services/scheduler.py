"""Scheduling service: decision matrix, time reservation, release, cancel.

Execution constraint: when a unit is chosen, its calculated duration is
reserved as a row in robot_schedule and the unit's Availability flag is
shifted to 'Active' (busy_until = end of window).  release_completed()
closes finished windows, flips the unit back to Available and moves it to
the delivery destination.
"""
import math
import threading

from backend.database import fetch_all, transaction
from backend.errors import BadRequestError, ConflictError, NotFoundError
from backend.services import audit, engine, settings
from backend.services.domains import default_domain_id, get_domain
from backend.services.fleet import ROBOT_SELECT
from backend.services.routing import load_graph, resolve_location, run_algorithm

LOCK = threading.RLock()
PRIORITY_RANK = "CASE d.priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END"
CHARGE_BELOW = 20            # unit goes to Charging when battery falls under this %
ALGO = "astar"
ALGO_LABEL = "A*"


def load_params():
    return engine.SchedParams(
        payload_alpha=settings.get_float("payload_alpha", 0.6),
        handling_seconds=settings.get_float("handling_seconds", 10),
        drain_per_m=settings.get_float("battery_drain_per_m", 0.05),
        battery_reserve=settings.get_float("battery_reserve", 10),
    )


# ------------------------------------------------------------------ matrix
def _matrix(conn, org_id, wt, src_id, dst_id, domain, params):
    graph = load_graph(conn)
    robots = conn.execute(ROBOT_SELECT + "WHERE r.org_id = %s ORDER BY r.robot_id", (org_id,)).fetchall()
    main = run_algorithm(graph, src_id, dst_id, ALGO)
    cache = {}
    distances = {}
    for r in robots:
        loc = r["current_location"]
        if main is None or loc is None:
            distances[r["robot_id"]] = (None, None)
            continue
        if loc not in cache:
            if loc == src_id:
                cache[loc] = (0.0, [src_id])
            else:
                leg = run_algorithm(graph, loc, src_id, ALGO)
                cache[loc] = (leg.distance, leg.path) if leg else (None, None)
        d1 = cache[loc][0]
        distances[r["robot_id"]] = (d1, main.distance if d1 is not None else None)
    pending = conn.execute("SELECT COUNT(*) AS n FROM deliveries WHERE org_id = %s "
                           "AND delivery_status = 'Pending'", (org_id,)).fetchone()["n"]
    rows, winner = engine.build_matrix(robots, wt, distances, domain, {"pending_count": pending}, params)
    return graph, robots, main, cache, rows, winner


def _pool_stats(robots, rows):
    return {
        "no_of_robots": len(robots),
        "available": sum(1 for r in rows if r["availability_ok"]),
        "capacity_ok": sum(1 for r in rows if r["capacity_ok"]),
        "eligible": sum(1 for r in rows if r["eligible"]),
    }


def decision_matrix(org_id, weight_kg, source, destination, domain_id=None, priority="Medium"):
    """What-if view: runs the whole decision pipeline but reserves nothing."""
    release_completed()
    params = load_params()
    with transaction() as conn:
        org = conn.execute("SELECT 1 FROM organizations WHERE org_id = %s", (org_id,)).fetchone()
        if not org:
            raise NotFoundError("Organization '%s' not found" % org_id)
        s, d = resolve_location(conn, source), resolve_location(conn, destination)
        if s["location_id"] == d["location_id"]:
            raise BadRequestError("Source and destination must be different")
        domain = get_domain(domain_id or default_domain_id(priority), conn)
        graph, robots, main, _, rows, winner = _matrix(
            conn, org_id, float(weight_kg), s["location_id"], d["location_id"], domain, params)
        return {
            "org_id": org_id, "weight_kg": float(weight_kg),
            "domain": {"domain_id": domain.domain_id, "name": domain.name,
                       "routing_class": domain.routing_class, "config": domain.config},
            "params": {"payload_alpha": params.payload_alpha, "handling_seconds": params.handling_seconds,
                       "drain_per_m": params.drain_per_m, "battery_reserve": params.battery_reserve},
            "pool": _pool_stats(robots, rows),
            "route": None if main is None else {
                "distance_meters": main.distance,
                "path": [graph.name(i) for i in main.path]},
            "selected_robot": winner["robot_id"] if winner else None,
            "matrix": rows,
        }


# --------------------------------------------------------------- scheduling
def schedule_delivery(delivery_id, mode="auto", forced_robot_id=None, actor="robo-auto"):
    """Pick a unit for a Pending delivery and reserve its time window."""
    with LOCK:
        release_completed()
        params = load_params()
        with transaction() as conn:
            d = conn.execute("SELECT * FROM deliveries WHERE delivery_id = %s FOR UPDATE",
                             (delivery_id,)).fetchone()
            if not d:
                raise NotFoundError("Delivery '%s' not found" % delivery_id)
            if d["delivery_status"] != "Pending":
                raise ConflictError("Delivery %s is %s, only Pending deliveries can be scheduled"
                                    % (delivery_id, d["delivery_status"]))
            domain = get_domain(d["domain_id"] or default_domain_id(d["priority"]), conn)
            wt = float(d["weight_kg"])
            graph, robots, main, cache, rows, winner = _matrix(
                conn, d["org_id"], wt, d["source_location"], d["destination_location"], domain, params)

            if main is None:
                note = "No route between source and destination (corridors blocked)."
                _note(conn, delivery_id, note)
                return _fail(delivery_id, note, rows, robots)

            if forced_robot_id:                                   # ---- manual override
                row = next((r for r in rows if r["robot_id"] == forced_robot_id), None)
                if row is None:
                    raise BadRequestError("Robot '%s' is not in organization %s's fleet"
                                          % (forced_robot_id, d["org_id"]))
                if not row["capacity_ok"]:
                    raise ConflictError("Capacity check failed: wt %.1f kg > capacity %.1f kg"
                                        % (wt, row["capacity_kg"]))
                if not row["availability_ok"]:
                    raise ConflictError("Robot %s is not available (%s)" % (forced_robot_id, row["status"]))
                if not row["route_ok"]:
                    raise ConflictError("Robot %s has no route to the pickup point" % forced_robot_id)
                if not row["trip_battery_ok"]:
                    raise ConflictError("Robot %s does not have enough battery for this trip" % forced_robot_id)
                chosen = row
                chosen["selected"] = True
                chosen["override"] = True
            else:
                if winner is None:
                    note = engine.summarise(rows)[:480]
                    _note(conn, delivery_id, note)
                    return _fail(delivery_id, note, rows, robots)
                chosen = winner

            return _reserve(conn, d, chosen, main, cache, graph, rows, robots, mode, actor, domain)


def _note(conn, delivery_id, note):
    conn.execute("UPDATE deliveries SET schedule_note = %s WHERE delivery_id = %s", (note, delivery_id))


def _fail(delivery_id, note, rows, robots):
    return {"scheduled": False, "delivery_id": delivery_id, "reason": note,
            "pool": _pool_stats(robots, rows), "matrix": rows}


def _reserve(conn, d, chosen, main, cache, graph, rows, robots, mode, actor, domain):
    import json
    est = chosen["estimate"]
    duration = float(est["total_s"])
    total_dist = round(chosen["dist_to_pickup_m"] + chosen["dist_delivery_m"], 2)
    pickup_names = []
    loc = next(r for r in robots if r["robot_id"] == chosen["robot_id"])["current_location"]
    if cache.get(loc) and cache[loc][1] and loc != d["source_location"]:
        pickup_names = [graph.name(i) for i in cache[loc][1]]
    delivery_names = [graph.name(i) for i in main.path]
    full_path = pickup_names[:-1] + delivery_names if pickup_names else delivery_names
    details = {"estimate": est, "domain": domain.domain_id, "score": chosen["score"],
               "override": bool(chosen.get("override")), "distance_m": total_dist}

    sched = conn.execute(
        "INSERT INTO robot_schedule (robot_id, delivery_id, start_time, end_time, duration_seconds, "
        "status, mode, details) VALUES (%s, %s, now(), now() + make_interval(secs => %s), %s, "
        "'Running', %s, %s::jsonb) RETURNING schedule_id, start_time, end_time",
        (chosen["robot_id"], d["delivery_id"], duration, duration, mode, json.dumps(details))).fetchone()
    conn.execute("UPDATE robots SET robot_status = 'Active', busy_until = %s WHERE robot_id = %s",
                 (sched["end_time"], chosen["robot_id"]))
    conn.execute(
        "UPDATE deliveries SET assigned_robot = %s, delivery_status = 'In Transit', domain_id = %s, "
        "algorithm_used = %s, route_distance_m = %s, route_path = %s, est_duration_seconds = %s, "
        "scheduled_start = %s, scheduled_end = %s, schedule_mode = %s, schedule_note = NULL "
        "WHERE delivery_id = %s",
        (chosen["robot_id"], domain.domain_id, ALGO_LABEL, total_dist, " -> ".join(full_path),
         duration, sched["start_time"], sched["end_time"], mode, d["delivery_id"]))
    audit.log(conn, "delivery", d["delivery_id"], "DELIVERY_SCHEDULED",
              {"robot": chosen["robot_id"], "mode": mode, "domain": domain.domain_id,
               "weight_kg": chosen["wt_kg"], "capacity_kg": chosen["capacity_kg"],
               "duration_s": duration, "distance_m": total_dist,
               "override": bool(chosen.get("override"))}, actor)
    return {
        "scheduled": True, "delivery_id": d["delivery_id"], "robot_id": chosen["robot_id"],
        "mode": mode, "domain": domain.domain_id, "estimate": est,
        "distance_m": total_dist, "route_path": full_path,
        "window": {"start": sched["start_time"], "end": sched["end_time"],
                   "duration_seconds": duration},
        "pool": _pool_stats(robots, rows), "matrix": rows,
    }


# ------------------------------------------------------------------ release
def _finish(conn, s, actor):
    """Close one reservation: delivery Delivered, robot freed and relocated."""
    d = conn.execute("SELECT destination_location, route_distance_m FROM deliveries "
                     "WHERE delivery_id = %s", (s["delivery_id"],)).fetchone()
    drain = int(math.ceil((d["route_distance_m"] or 0) * settings.get_float("battery_drain_per_m", 0.05)))
    conn.execute("UPDATE robot_schedule SET status = 'Completed' WHERE schedule_id = %s", (s["schedule_id"],))
    conn.execute("UPDATE deliveries SET delivery_status = 'Delivered', delivered_at = now() "
                 "WHERE delivery_id = %s", (s["delivery_id"],))
    conn.execute(
        "UPDATE robots SET current_location = %s, busy_until = NULL, "
        "battery_percentage = GREATEST(0, battery_percentage - %s), "
        "robot_status = CASE WHEN GREATEST(0, battery_percentage - %s) < %s "
        "THEN 'Charging' ELSE 'Available' END WHERE robot_id = %s",
        (d["destination_location"], drain, drain, CHARGE_BELOW, s["robot_id"]))
    audit.log(conn, "delivery", s["delivery_id"], "DELIVERY_COMPLETED",
              {"robot": s["robot_id"], "battery_used_pct": drain}, actor)


def release_completed(actor="robo-clock"):
    """Free every unit whose reserved window has elapsed."""
    with LOCK, transaction() as conn:
        due = conn.execute("SELECT schedule_id, robot_id, delivery_id FROM robot_schedule "
                           "WHERE status = 'Running' AND end_time <= now() FOR UPDATE").fetchall()
        for s in due:
            _finish(conn, s, actor)
        return [s["delivery_id"] for s in due]


def complete_now(delivery_id, actor="operator"):
    """Demo helper: finish a running delivery immediately."""
    with LOCK, transaction() as conn:
        s = conn.execute("SELECT schedule_id, robot_id, delivery_id FROM robot_schedule "
                         "WHERE delivery_id = %s AND status = 'Running' FOR UPDATE", (delivery_id,)).fetchone()
        if not s:
            raise ConflictError("Delivery '%s' has no running task" % delivery_id)
        conn.execute("UPDATE robot_schedule SET end_time = now() WHERE schedule_id = %s", (s["schedule_id"],))
        _finish(conn, s, actor)
    return {"completed": delivery_id}


def cancel_delivery(delivery_id, actor="operator"):
    with LOCK, transaction() as conn:
        d = conn.execute("SELECT delivery_status, assigned_robot FROM deliveries WHERE delivery_id = %s "
                         "FOR UPDATE", (delivery_id,)).fetchone()
        if not d:
            raise NotFoundError("Delivery '%s' not found" % delivery_id)
        if d["delivery_status"] in ("Delivered", "Cancelled", "Failed"):
            raise ConflictError("Delivery is already %s" % d["delivery_status"])
        if d["delivery_status"] in ("In Transit", "Assigned"):
            conn.execute("UPDATE robot_schedule SET status = 'Cancelled', end_time = now() "
                         "WHERE delivery_id = %s AND status = 'Running'", (delivery_id,))
            if d["assigned_robot"]:
                conn.execute("UPDATE robots SET robot_status = 'Available', busy_until = NULL "
                             "WHERE robot_id = %s", (d["assigned_robot"],))
        conn.execute("UPDATE deliveries SET delivery_status = 'Cancelled' WHERE delivery_id = %s", (delivery_id,))
        audit.log(conn, "delivery", delivery_id, "DELIVERY_CANCELLED", {}, actor)
    return {"cancelled": delivery_id}


# --------------------------------------------------------------- auto cycle
def run_auto_cycle(actor="robo-auto"):
    """One pass of Robo Mode: release finished units, then schedule every
    Pending delivery in priority order (Critical > High > Medium > Low)."""
    with LOCK:
        released = release_completed()
        pending = fetch_all("SELECT d.delivery_id FROM deliveries d WHERE d.delivery_status = 'Pending' "
                            "ORDER BY " + PRIORITY_RANK + ", d.created_at, d.delivery_id")
        results = []
        for p in pending:
            try:
                res = schedule_delivery(p["delivery_id"], "auto", None, actor)
                results.append({"delivery_id": p["delivery_id"], "scheduled": res["scheduled"],
                                "robot_id": res.get("robot_id"), "reason": res.get("reason")})
            except Exception as exc:        # one bad delivery must not stop the loop
                results.append({"delivery_id": p["delivery_id"], "scheduled": False, "reason": str(exc)})
        return {"released": released, "attempted": len(results),
                "scheduled": sum(1 for r in results if r["scheduled"]), "results": results}


def timeline(org_id=None, limit=40):
    sql = ("SELECT s.schedule_id, s.robot_id, s.delivery_id, s.start_time, s.end_time, "
           "s.duration_seconds, s.status, s.mode, r.org_id FROM robot_schedule s "
           "JOIN robots r ON r.robot_id = s.robot_id WHERE TRUE")
    params = []
    if org_id:
        sql += " AND r.org_id = %s"
        params.append(org_id)
    sql += " ORDER BY s.start_time DESC, s.schedule_id DESC LIMIT %s"
    params.append(int(limit))
    return fetch_all(sql, params)
