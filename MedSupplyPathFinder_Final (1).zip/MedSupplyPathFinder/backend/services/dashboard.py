from backend.database import fetch_one
from backend.services import settings


def summary(org_id=None):
    flt = " AND org_id = %s" if org_id else ""
    prm = (org_id,) if org_id else None
    q = lambda sql: fetch_one(sql, prm)["n"]
    return {
        "org_id": org_id,
        "total_deliveries": q("SELECT COUNT(*)::int AS n FROM deliveries WHERE TRUE" + flt),
        "pending_deliveries": q("SELECT COUNT(*)::int AS n FROM deliveries WHERE delivery_status = 'Pending'" + flt),
        "active_routes": q("SELECT COUNT(*)::int AS n FROM deliveries WHERE delivery_status = 'In Transit'" + flt),
        "emergency_deliveries": q("SELECT COUNT(*)::int AS n FROM deliveries WHERE priority = 'Critical'" + flt),
        "completed_deliveries": q("SELECT COUNT(*)::int AS n FROM deliveries WHERE delivery_status = 'Delivered'" + flt),
        "total_robots": q("SELECT COUNT(*)::int AS n FROM robots WHERE TRUE" + flt),
        "active_robots": q("SELECT COUNT(*)::int AS n FROM robots WHERE robot_status = 'Active'" + flt),
        "available_robots": q("SELECT COUNT(*)::int AS n FROM robots WHERE robot_status = 'Available' "
                              "AND (busy_until IS NULL OR busy_until <= now())" + flt),
        "avg_delivery_seconds": fetch_one(
            "SELECT COALESCE(AVG(EXTRACT(EPOCH FROM (delivered_at - scheduled_start))), 0)::float8 AS n "
            "FROM deliveries WHERE delivery_status = 'Delivered' AND scheduled_start IS NOT NULL" + flt, prm)["n"],
        "robo_mode": settings.get_mode(),
    }
