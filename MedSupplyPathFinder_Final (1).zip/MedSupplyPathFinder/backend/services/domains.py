"""Domain configurations: Emergency, Medical and Dynamic (Set A) routing classes,
plus the action that refreshes domain names."""
from backend.database import fetch_all, fetch_one, transaction
from backend.errors import BadRequestError, NotFoundError
from backend.services import audit, settings


class RoutingDomain:
    routing_class = "Base"
    defaults = {"speed_multiplier": 1.0, "min_battery": 20}

    def __init__(self, domain_id, name, config=None, option_set=None):
        self.domain_id = domain_id
        self.name = name
        self.option_set = option_set
        self.config = {**self.defaults, **(config or {})}

    @property
    def speed_multiplier(self):
        return float(self.config["speed_multiplier"])

    @property
    def min_battery(self):
        return int(self.config["min_battery"])

    def score(self, row, ctx):          # lower is better
        return row["eta_seconds"]

    def rank(self, eligible, ctx):
        for r in eligible:
            r["score"] = round(self.score(r, ctx), 4)
        eligible.sort(key=lambda r: (r["score"], r["robot_id"]))
        for i, r in enumerate(eligible, 1):
            r["rank"] = i


class EmergencyDomain(RoutingDomain):
    """Fastest unit wins.  Priority corridors give a speed boost (x1.25) and a
    lower battery floor (15 %) because speed matters more than reserve."""
    routing_class = "Emergency"
    defaults = {"speed_multiplier": 1.25, "min_battery": 15}

    def score(self, row, ctx):
        return row["eta_seconds"]


class MedicalDomain(RoutingDomain):
    """Gentle, safe handling.  Needs 30 % battery and penalises high load
    utilisation and low battery:  score = ETA x (1 + utilisation) x (1 + (100-battery)/200)."""
    routing_class = "Medical"
    defaults = {"speed_multiplier": 1.0, "min_battery": 30}

    def score(self, row, ctx):
        return (row["eta_seconds"] * (1 + row["utilisation"])
                * (1 + (100 - row["battery"]) / 200.0))


class DynamicDomain(RoutingDomain):
    """Dynamic (Set A): weighted, normalised blend of ETA, battery and load.
    When the pending queue is long the ETA weight is boosted automatically."""
    routing_class = "Dynamic"
    defaults = {"speed_multiplier": 1.1, "min_battery": 20,
                "weights": {"eta": 0.5, "battery": 0.3, "utilisation": 0.2},
                "pressure_threshold": 3, "pressure_boost": 0.2}

    def weights(self, ctx):
        w = dict(self.config.get("weights") or self.defaults["weights"])
        if ctx.get("pending_count", 0) >= self.config.get("pressure_threshold", 3):
            w["eta"] = w.get("eta", 0.5) + float(self.config.get("pressure_boost", 0.2))
        total = sum(w.values()) or 1.0
        return {k: v / total for k, v in w.items()}

    @staticmethod
    def _norm(values):
        lo, hi = min(values), max(values)
        return [0.0 if hi == lo else (v - lo) / (hi - lo) for v in values]

    def rank(self, eligible, ctx):
        if not eligible:
            return
        w = self.weights(ctx)
        eta = self._norm([r["eta_seconds"] for r in eligible])
        bat = self._norm([r["battery"] for r in eligible])
        util = self._norm([r["utilisation"] for r in eligible])
        for r, e, b, u in zip(eligible, eta, bat, util):
            r["score"] = round(w.get("eta", 0) * e + w.get("battery", 0) * (1 - b)
                               + w.get("utilisation", 0) * u, 4)
        eligible.sort(key=lambda r: (r["score"], r["robot_id"]))
        for i, r in enumerate(eligible, 1):
            r["rank"] = i


DOMAIN_CLASSES = {
    "Emergency": EmergencyDomain,
    "Medical": MedicalDomain,
    "Dynamic": DynamicDomain,
}


def build_domain(row):
    cls = DOMAIN_CLASSES[row["routing_class"]]
    return cls(row["domain_id"], row["domain_name"], row.get("config") or {},
               row.get("option_set"))


def default_domain_id(priority):
    return "DOM-EMG" if priority == "Critical" else "DOM-MED"


def get_domain(domain_id, conn=None):
    sql = "SELECT * FROM domains WHERE domain_id = %s"
    row = conn.execute(sql, (domain_id,)).fetchone() if conn is not None else fetch_one(sql, (domain_id,))
    if not row:
        raise NotFoundError("Domain '%s' not found" % domain_id)
    if not row["is_active"]:
        raise BadRequestError("Domain '%s' is not active" % domain_id)
    return build_domain(row)


def list_domains():
    return fetch_all("SELECT domain_id, routing_class, domain_name, option_set, config, "
                     "is_active, names_refreshed_at, updated_at FROM domains ORDER BY domain_id")


def update_domain(domain_id, domain_name=None, config=None, is_active=None, actor="operator"):
    import json
    with transaction() as conn:
        row = conn.execute("SELECT * FROM domains WHERE domain_id = %s", (domain_id,)).fetchone()
        if not row:
            raise NotFoundError("Domain '%s' not found" % domain_id)
        if config is not None:
            for key in ("speed_multiplier", "min_battery"):
                if key in config:
                    try:
                        val = float(config[key])
                    except (TypeError, ValueError):
                        raise BadRequestError("%s must be a number" % key)
                    if val <= 0 or (key == "min_battery" and val > 100):
                        raise BadRequestError("%s out of range" % key)
            merged = {**(row["config"] or {}), **config}
            conn.execute("UPDATE domains SET config = %s::jsonb WHERE domain_id = %s",
                         (json.dumps(merged), domain_id))
        if domain_name is not None:
            conn.execute("UPDATE domains SET domain_name = %s WHERE domain_id = %s",
                         (domain_name, domain_id))
        if is_active is not None:
            conn.execute("UPDATE domains SET is_active = %s WHERE domain_id = %s",
                         (bool(is_active), domain_id))
        audit.log(conn, "domain", domain_id, "DOMAIN_UPDATED",
                  {"name": domain_name, "config": config, "is_active": is_active}, actor)
        return conn.execute("SELECT * FROM domains WHERE domain_id = %s", (domain_id,)).fetchone()


def refresh_domain_names(org_id=None, renames=None, actor="operator"):
    """Dedicated action: regenerate every active domain's name from its
    name_template and the organization master (or apply explicit renames),
    then stamp names_refreshed_at.  Returns the before/after list."""
    renames = renames or {}
    with transaction() as conn:
        org_id = org_id or settings.get("default_org", "ORG-001")
        org = conn.execute("SELECT org_id, org_name FROM organizations WHERE org_id = %s",
                           (org_id,)).fetchone()
        if not org:
            raise NotFoundError("Organization '%s' not found" % org_id)
        changes = []
        for d in conn.execute("SELECT * FROM domains WHERE is_active ORDER BY domain_id").fetchall():
            if d["domain_id"] in renames:
                new = str(renames[d["domain_id"]]).strip()
                if not new:
                    raise BadRequestError("Domain name cannot be empty")
            else:
                tpl = (d["config"] or {}).get("name_template", "{org} - {routing_class} Domain")
                new = tpl.format(org=org["org_name"], routing_class=d["routing_class"],
                                 set=d["option_set"] or "")
            conn.execute("UPDATE domains SET domain_name = %s, names_refreshed_at = now() "
                         "WHERE domain_id = %s", (new, d["domain_id"]))
            changes.append({"domain_id": d["domain_id"], "old_name": d["domain_name"],
                            "new_name": new, "changed": new != d["domain_name"]})
        audit.log(conn, "domain", "ALL", "DOMAIN_NAMES_REFRESHED",
                  {"org_id": org_id, "changes": changes}, actor)
        return {"org_id": org_id, "domains": changes}
