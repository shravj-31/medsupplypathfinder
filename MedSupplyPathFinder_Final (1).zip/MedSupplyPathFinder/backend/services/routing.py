"""Route calculation on the hospital graph (Dijkstra / A*), edge blocking."""
from algorithms.astar import astar
from algorithms.dijkstra import dijkstra
from algorithms.graph import Graph
from backend.database import fetch_all, transaction
from backend.errors import BadRequestError, NotFoundError
from backend.services import audit

ALGORITHMS = {"dijkstra": dijkstra, "astar": astar}


def load_graph(conn):
    locs = conn.execute(
        "SELECT location_id, location_name, x_coordinate, y_coordinate, is_accessible "
        "FROM locations").fetchall()
    edges = conn.execute(
        "SELECT source_location, destination_location, distance_meters "
        "FROM graph_edges WHERE is_blocked = FALSE").fetchall()
    return Graph.from_rows(locs, edges)


def resolve_location(conn, name):
    row = conn.execute(
        "SELECT location_id, location_name FROM locations "
        "WHERE lower(location_name) = lower(%s)", (str(name).strip(),)).fetchone()
    if not row:
        raise NotFoundError("Location '%s' not found" % name)
    return row


def run_algorithm(graph, src, dst, algorithm="astar"):
    fn = ALGORITHMS.get(str(algorithm).lower().replace("*", "star"))
    if fn is None:
        raise BadRequestError("algorithm must be 'dijkstra' or 'astar'")
    if src == dst:
        return None
    return fn(graph, src, dst)


def _format(graph, res):
    return {
        "algorithm": res.algorithm,
        "distance_meters": res.distance,
        "path": [{"location_id": i, "location_name": graph.name(i)} for i in res.path],
        "nodes_explored": res.nodes_explored,
        "execution_ms": res.execution_ms,
    }


def calculate(source, destination, algorithm="astar"):
    with transaction() as conn:
        s = resolve_location(conn, source)
        d = resolve_location(conn, destination)
        if s["location_id"] == d["location_id"]:
            raise BadRequestError("Source and destination must be different")
        graph = load_graph(conn)
        res = run_algorithm(graph, s["location_id"], d["location_id"], algorithm)
        if res is None:
            raise NotFoundError("No route available between %s and %s "
                                "(corridors may be blocked)" % (s["location_name"], d["location_name"]))
        audit.log(conn, "route", "%s->%s" % (s["location_name"], d["location_name"]),
                  "ROUTE_CALCULATED", {"algorithm": res.algorithm, "distance_m": res.distance})
        return _format(graph, res)


def compare(source, destination):
    with transaction() as conn:
        s = resolve_location(conn, source)
        d = resolve_location(conn, destination)
        if s["location_id"] == d["location_id"]:
            raise BadRequestError("Source and destination must be different")
        graph = load_graph(conn)
        out = {}
        for key in ("dijkstra", "astar"):
            res = run_algorithm(graph, s["location_id"], d["location_id"], key)
            if res is None:
                raise NotFoundError("No route available between %s and %s"
                                    % (s["location_name"], d["location_name"]))
            out[key] = _format(graph, res)
        out["same_distance"] = out["dijkstra"]["distance_meters"] == out["astar"]["distance_meters"]
        return out


def list_locations():
    return fetch_all("SELECT location_id, location_name, location_type, building_name, "
                     "floor_number, x_coordinate, y_coordinate, is_accessible "
                     "FROM locations ORDER BY location_id")


def list_edges():
    """One row per corridor (the mirrored reverse edge is hidden)."""
    return fetch_all(
        "SELECT e.edge_id, s.location_name AS source, d.location_name AS destination, "
        "e.distance_meters, e.edge_type, e.is_blocked "
        "FROM graph_edges e "
        "JOIN locations s ON s.location_id = e.source_location "
        "JOIN locations d ON d.location_id = e.destination_location "
        "WHERE e.source_location < e.destination_location "
        "OR NOT EXISTS (SELECT 1 FROM graph_edges r WHERE r.source_location = e.destination_location "
        "AND r.destination_location = e.source_location) "
        "ORDER BY e.edge_id")


def set_edge_blocked(source, destination, blocked, actor="operator"):
    with transaction() as conn:
        s = resolve_location(conn, source)
        d = resolve_location(conn, destination)
        rows = conn.execute(
            "UPDATE graph_edges SET is_blocked = %s "
            "WHERE (source_location = %s AND destination_location = %s) "
            "OR (source_location = %s AND destination_location = %s) RETURNING edge_id",
            (bool(blocked), s["location_id"], d["location_id"],
             d["location_id"], s["location_id"])).fetchall()
        if not rows:
            raise NotFoundError("No corridor between %s and %s"
                                % (s["location_name"], d["location_name"]))
        audit.log(conn, "route", "%s<->%s" % (s["location_name"], d["location_name"]),
                  "ROUTE_BLOCKED" if blocked else "ROUTE_UNBLOCKED",
                  {"edges_changed": len(rows)}, actor)
        return {"source": s["location_name"], "destination": d["location_name"],
                "is_blocked": bool(blocked), "edges_changed": len(rows)}
