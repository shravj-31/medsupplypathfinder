"""Decision-matrix scheduling engine.  PURE PYTHON: no database, no web.

Inputs per task                       Source
  wt            payload weight (kg)   task request
  Capacity      unit load ceiling     robots.load_capacity_kg
  Availability  free / busy / ...     robots.robot_status + busy_until
  No. of Robots pooled units in org   len(robots)

Pipeline for each unit in the pool
  1. Availability filter   (busy / charging / offline / maintenance dropped)
  2. Capacity check        wt <= Capacity, otherwise the unit is dropped
  3. Domain battery rule   (Emergency 15 %, Medical 30 %, Dynamic 20 %)
  4. Route exists          (blocked corridors are respected)
  5. Trip battery          enough charge for the whole trip + reserve
  6. Time estimation       see estimate_time()
  7. Domain ranking        the routing class picks the winner
"""
from dataclasses import dataclass


@dataclass
class SchedParams:
    payload_alpha: float = 0.6        # slowdown at full load = 1 + alpha
    handling_seconds: float = 10.0    # load + unload time per task
    drain_per_m: float = 0.05         # battery % used per meter
    battery_reserve: float = 10.0     # % that must remain after the trip


def payload_coefficient(wt, capacity, alpha=0.6):
    """Dynamic coefficient from the payload: 1.0 (empty) .. 1+alpha (full)."""
    if capacity <= 0:
        raise ValueError("capacity must be > 0")
    return 1.0 + alpha * (wt / capacity)


def estimate_time(d_pickup, d_delivery, base_speed, wt, capacity,
                  speed_multiplier=1.0, params=None):
    """Total task time in seconds.

    speed        = base_speed * domain speed multiplier
    empty leg    = d_pickup   / speed                      (no payload yet)
    loaded leg   = d_delivery * coeff(wt) / speed          (slowed by payload)
    total        = empty leg + loaded leg + handling
    """
    p = params or SchedParams()
    coeff = payload_coefficient(wt, capacity, p.payload_alpha)
    speed = base_speed * speed_multiplier
    empty = d_pickup / speed
    loaded = d_delivery * coeff / speed
    total = empty + loaded + p.handling_seconds
    return {
        "payload_coeff": round(coeff, 4),
        "effective_speed_mps": round(speed / coeff, 4),
        "empty_leg_s": round(empty, 2),
        "loaded_leg_s": round(loaded, 2),
        "handling_s": round(p.handling_seconds, 2),
        "total_s": round(total, 2),
    }


def evaluate_robot(robot, wt, d_pickup, d_delivery, domain, params=None):
    """Build one decision-matrix row for one unit."""
    p = params or SchedParams()
    cap = float(robot["load_capacity_kg"])
    battery = int(robot["battery_percentage"])
    available = bool(robot["is_available"])
    capacity_ok = wt <= cap
    battery_ok = battery >= domain.min_battery
    route_ok = d_pickup is not None and d_delivery is not None

    est = None
    trip_ok = False
    if route_ok:
        est = estimate_time(d_pickup, d_delivery, float(robot["base_speed_mps"]),
                            wt, cap, domain.speed_multiplier, p)
        needed = (d_pickup + d_delivery) * p.drain_per_m
        trip_ok = (battery - needed) >= p.battery_reserve

    if not available:
        reason = "Unavailable (%s)" % robot["robot_status"]
    elif not capacity_ok:
        reason = "Over capacity (wt %.1f kg > %.1f kg)" % (wt, cap)
    elif not battery_ok:
        reason = "Battery %d%% below %s minimum %d%%" % (battery, domain.routing_class, domain.min_battery)
    elif not route_ok:
        reason = "No route (corridors blocked)"
    elif not trip_ok:
        reason = "Battery too low for this trip"
    else:
        reason = "OK"

    return {
        "robot_id": robot["robot_id"],
        "robot_type": robot["robot_type"],
        "status": robot["robot_status"],
        "location": robot.get("current_location_name"),
        "battery": battery,
        "capacity_kg": cap,
        "wt_kg": wt,
        "utilisation": round(wt / cap, 3),
        "base_speed_mps": float(robot["base_speed_mps"]),
        "availability_ok": available,
        "capacity_ok": capacity_ok,
        "battery_ok": battery_ok,
        "route_ok": route_ok,
        "trip_battery_ok": trip_ok,
        "eligible": available and capacity_ok and battery_ok and route_ok and trip_ok,
        "reason": reason,
        "dist_to_pickup_m": None if d_pickup is None else round(d_pickup, 2),
        "dist_delivery_m": None if d_delivery is None else round(d_delivery, 2),
        "estimate": est,
        "eta_seconds": est["total_s"] if est else None,
        "score": None,
        "rank": None,
        "selected": False,
    }


def build_matrix(robots, wt, distances, domain, ctx=None, params=None):
    """robots: list of robot dicts.  distances: robot_id -> (d_pickup, d_delivery).
    Returns (rows, winner_row_or_None).  Eligible rows come first, ranked."""
    rows = []
    for r in robots:
        d1, d2 = distances.get(r["robot_id"], (None, None))
        rows.append(evaluate_robot(r, wt, d1, d2, domain, params))
    eligible = [r for r in rows if r["eligible"]]
    domain.rank(eligible, ctx or {})
    winner = eligible[0] if eligible else None
    if winner:
        winner["selected"] = True
    rest = sorted([r for r in rows if not r["eligible"]], key=lambda r: r["robot_id"])
    return eligible + rest, winner


def summarise(rows):
    """Compact reason string used as the delivery's schedule note."""
    bad = ["%s: %s" % (r["robot_id"], r["reason"]) for r in rows if not r["eligible"]]
    return "No eligible unit. " + "; ".join(bad) if bad else "No eligible unit."
