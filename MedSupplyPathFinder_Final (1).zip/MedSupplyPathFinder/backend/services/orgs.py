"""Organization Master (custom IDs)."""
from backend.database import fetch_all, fetch_one, transaction
from backend.errors import ConflictError, NotFoundError
from backend.services import audit

SELECT = ("SELECT o.org_id, o.org_name, o.org_type, o.contact_email, o.is_active, "
          "o.created_at, o.updated_at, "
          "(SELECT COUNT(*) FROM robots r WHERE r.org_id = o.org_id)::int AS robot_count, "
          "(SELECT COUNT(*) FROM robots r WHERE r.org_id = o.org_id "
          " AND r.robot_status = 'Available' AND (r.busy_until IS NULL OR r.busy_until <= now()))::int AS available_count, "
          "(SELECT COUNT(*) FROM deliveries d WHERE d.org_id = o.org_id)::int AS delivery_count "
          "FROM organizations o ")


def list_orgs():
    return fetch_all(SELECT + "ORDER BY o.org_id")


def get_org(org_id):
    row = fetch_one(SELECT + "WHERE o.org_id = %s", (org_id,))
    if not row:
        raise NotFoundError("Organization '%s' not found" % org_id)
    return row


def create_org(org_id, org_name, org_type="Hospital", contact_email=None, actor="operator"):
    with transaction() as conn:
        if conn.execute("SELECT 1 FROM organizations WHERE org_id = %s OR lower(org_name) = lower(%s)",
                        (org_id, org_name)).fetchone():
            raise ConflictError("Organization ID or name already exists")
        conn.execute("INSERT INTO organizations (org_id, org_name, org_type, contact_email) "
                     "VALUES (%s, %s, %s, %s)", (org_id, org_name, org_type, contact_email))
        audit.log(conn, "organization", org_id, "ORG_CREATED",
                  {"name": org_name, "type": org_type}, actor)
    return get_org(org_id)


def update_org(org_id, fields, actor="operator"):
    allowed = ("org_name", "org_type", "contact_email", "is_active")
    sets = [(k, v) for k, v in fields.items() if k in allowed and v is not None]
    get_org(org_id)
    if sets:
        with transaction() as conn:
            conn.execute("UPDATE organizations SET " + ", ".join("%s = %%s" % k for k, _ in sets)
                         + " WHERE org_id = %s", [v for _, v in sets] + [org_id])
            audit.log(conn, "organization", org_id, "ORG_UPDATED", dict(sets), actor)
    return get_org(org_id)


def delete_org(org_id, actor="operator"):
    get_org(org_id)
    with transaction() as conn:
        n = conn.execute("SELECT COUNT(*) AS n FROM robots WHERE org_id = %s", (org_id,)).fetchone()["n"]
        m = conn.execute("SELECT COUNT(*) AS n FROM deliveries WHERE org_id = %s", (org_id,)).fetchone()["n"]
        if n or m:
            raise ConflictError("Organization still has %d robot(s) and %d delivery(ies); remove them first" % (n, m))
        conn.execute("DELETE FROM organizations WHERE org_id = %s", (org_id,))
        audit.log(conn, "organization", org_id, "ORG_DELETED", {}, actor)
    return {"deleted": org_id}
