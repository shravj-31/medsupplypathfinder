"""Fleet multi-tenancy: add / remove / update robot nodes on the fly."""
import re

from backend.database import fetch_all, fetch_one, transaction
from backend.errors import BadRequestError, ConflictError, NotFoundError
from backend.services import audit
from backend.services.routing import resolve_location

ROBOT_SELECT = (
    "SELECT r.robot_id, r.org_id, r.robot_type, r.battery_percentage, r.robot_status, "
    "r.current_location, l.location_name AS current_location_name, "
    "r.load_capacity_kg, r.base_speed_mps, r.busy_until, "
    "(r.robot_status = 'Available' AND (r.busy_until IS NULL OR r.busy_until <= now())) AS is_available, "
    "GREATEST(0, COALESCE(EXTRACT(EPOCH FROM (r.busy_until - now())), 0))::float8 AS seconds_remaining, "
    "(SELECT s.delivery_id FROM robot_schedule s WHERE s.robot_id = r.robot_id "
    " AND s.status = 'Running' LIMIT 1) AS current_delivery, "
    "r.created_at, r.updated_at "
    "FROM robots r LEFT JOIN locations l ON l.location_id = r.current_location ")

STATUSES = ("Available", "Charging", "Offline", "Maintenance")


def list_robots(org_id=None, status=None):
    sql, params = ROBOT_SELECT + "WHERE TRUE", []
    if org_id:
        sql += " AND r.org_id = %s"
        params.append(org_id)
    if status:
        sql += " AND r.robot_status = %s"
        params.append(status)
    return fetch_all(sql + " ORDER BY r.org_id, r.robot_id", params)


def get_robot(robot_id):
    row = fetch_one(ROBOT_SELECT + "WHERE r.robot_id = %s", (robot_id,))
    if not row:
        raise NotFoundError("Robot '%s' not found" % robot_id)
    return row


def fleet_summary(org_id=None):
    robots = list_robots(org_id)
    by_status = {}
    for r in robots:
        by_status[r["robot_status"]] = by_status.get(r["robot_status"], 0) + 1
    return {
        "org_id": org_id,
        "no_of_robots": len(robots),
        "available": sum(1 for r in robots if r["is_available"]),
        "total_capacity_kg": round(sum(r["load_capacity_kg"] for r in robots), 2),
        "max_unit_capacity_kg": max([r["load_capacity_kg"] for r in robots], default=0),
        "by_status": by_status,
    }


def _next_id(conn, robot_type):
    prefix = "DR" if robot_type == "Drone" else "RB"
    rows = conn.execute("SELECT robot_id FROM robots WHERE robot_id ~ %s",
                        ("^%s[0-9]+$" % prefix,)).fetchall()
    nums = [int(re.sub(r"\D", "", r["robot_id"])) for r in rows]
    return "%s%03d" % (prefix, (max(nums) if nums else 0) + 1)


def add_robot(org_id, robot_type="Robot", robot_id=None, battery_percentage=100,
              load_capacity_kg=10.0, base_speed_mps=1.5, current_location="Pharmacy",
              robot_status="Available", actor="operator"):
    if robot_status not in STATUSES:
        raise BadRequestError("robot_status must be one of %s" % ", ".join(STATUSES))
    with transaction() as conn:
        org = conn.execute("SELECT is_active FROM organizations WHERE org_id = %s", (org_id,)).fetchone()
        if not org:
            raise NotFoundError("Organization '%s' not found" % org_id)
        if not org["is_active"]:
            raise ConflictError("Organization '%s' is inactive" % org_id)
        loc = resolve_location(conn, current_location)
        robot_id = (robot_id or "").strip() or _next_id(conn, robot_type)
        if not re.match(r"^[A-Za-z0-9_-]{3,20}$", robot_id):
            raise BadRequestError("robot_id must be 3-20 letters/digits/_/-")
        if conn.execute("SELECT 1 FROM robots WHERE robot_id = %s", (robot_id,)).fetchone():
            raise ConflictError("Robot '%s' already exists" % robot_id)
        conn.execute(
            "INSERT INTO robots (robot_id, org_id, robot_type, battery_percentage, robot_status, "
            "current_location, load_capacity_kg, base_speed_mps) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
            (robot_id, org_id, robot_type, battery_percentage, robot_status,
             loc["location_id"], load_capacity_kg, base_speed_mps))
        audit.log(conn, "robot", robot_id, "FLEET_ADD",
                  {"org_id": org_id, "type": robot_type, "capacity_kg": load_capacity_kg,
                   "speed_mps": base_speed_mps, "location": loc["location_name"]}, actor)
    return get_robot(robot_id)


def remove_robot(robot_id, force=False, actor="operator"):
    with transaction() as conn:
        robot = conn.execute("SELECT robot_id, org_id FROM robots WHERE robot_id = %s "
                             "FOR UPDATE", (robot_id,)).fetchone()
        if not robot:
            raise NotFoundError("Robot '%s' not found" % robot_id)
        running = conn.execute("SELECT delivery_id FROM robot_schedule WHERE robot_id = %s "
                               "AND status = 'Running'", (robot_id,)).fetchone()
        requeued = None
        if running:
            if not force:
                raise ConflictError("Robot '%s' is busy with %s. Use force=true to remove it "
                                    "and re-queue the delivery." % (robot_id, running["delivery_id"]))
            requeued = running["delivery_id"]
            conn.execute("UPDATE robot_schedule SET status = 'Cancelled', end_time = now() "
                         "WHERE robot_id = %s AND status = 'Running'", (robot_id,))
            conn.execute("UPDATE deliveries SET delivery_status = 'Pending', assigned_robot = NULL, "
                         "scheduled_start = NULL, scheduled_end = NULL, "
                         "schedule_note = %s WHERE delivery_id = %s",
                         ("Re-queued: robot %s was removed from the fleet" % robot_id, requeued))
        conn.execute("DELETE FROM robots WHERE robot_id = %s", (robot_id,))
        audit.log(conn, "robot", robot_id, "FLEET_REMOVE",
                  {"org_id": robot["org_id"], "forced": bool(force), "requeued_delivery": requeued}, actor)
    return {"removed": robot_id, "requeued_delivery": requeued}


def update_robot(robot_id, fields, actor="operator"):
    allowed = ("robot_status", "battery_percentage", "load_capacity_kg", "base_speed_mps",
               "current_location")
    changes = {k: v for k, v in fields.items() if k in allowed and v is not None}
    with transaction() as conn:
        robot = conn.execute("SELECT robot_status FROM robots WHERE robot_id = %s FOR UPDATE",
                             (robot_id,)).fetchone()
        if not robot:
            raise NotFoundError("Robot '%s' not found" % robot_id)
        busy = conn.execute("SELECT 1 FROM robot_schedule WHERE robot_id = %s AND status = 'Running'",
                            (robot_id,)).fetchone()
        if busy and ("robot_status" in changes or "current_location" in changes):
            raise ConflictError("Robot '%s' is running a task; status/location cannot change now" % robot_id)
        if "robot_status" in changes and changes["robot_status"] not in STATUSES:
            raise BadRequestError("robot_status must be one of %s" % ", ".join(STATUSES))
        if "current_location" in changes:
            changes["current_location"] = resolve_location(conn, changes["current_location"])["location_id"]
        if changes:
            conn.execute("UPDATE robots SET " + ", ".join("%s = %%s" % k for k in changes)
                         + " WHERE robot_id = %s", list(changes.values()) + [robot_id])
            audit.log(conn, "robot", robot_id, "ROBOT_UPDATED", changes, actor)
    return get_robot(robot_id)
