"""Key/value system settings (Robo Mode, tunables)."""
from backend.database import fetch_one, transaction
from backend.errors import BadRequestError

ROBO_MODES = ("auto", "manual")


def get(key, default=None):
    row = fetch_one("SELECT value FROM system_settings WHERE key = %s", (key,))
    return row["value"] if row else default


def get_float(key, default):
    try:
        return float(get(key, default))
    except (TypeError, ValueError):
        return float(default)


def set_value(key, value, conn=None):
    sql = ("INSERT INTO system_settings (key, value) VALUES (%s, %s) "
           "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()")
    if conn is not None:
        conn.execute(sql, (key, str(value)))
    else:
        with transaction() as c:
            c.execute(sql, (key, str(value)))


def get_mode():
    return get("robo_mode", "manual")


def set_mode(mode, actor="operator"):
    from backend.services import audit
    if mode not in ROBO_MODES:
        raise BadRequestError("mode must be 'auto' or 'manual'")
    with transaction() as conn:
        old = conn.execute("SELECT value FROM system_settings WHERE key='robo_mode'").fetchone()
        set_value("robo_mode", mode, conn)
        audit.log(conn, "system", "robo_mode", "MODE_CHANGED",
                  {"from": old["value"] if old else None, "to": mode}, actor)
    return mode


def all_settings():
    from backend.database import fetch_all
    return {r["key"]: r["value"] for r in fetch_all("SELECT key, value FROM system_settings")}
