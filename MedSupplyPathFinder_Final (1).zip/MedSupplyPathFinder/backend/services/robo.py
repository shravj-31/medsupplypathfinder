"""Robo Mode: automated background scheduling + manual override."""
import asyncio
import logging
from datetime import datetime, timezone

from backend.database import fetch_one
from backend.errors import ConflictError
from backend.services import scheduler, settings

log = logging.getLogger("robo")
STATE = {"last_run": None, "last_result": None, "cycles": 0, "last_error": None}


def _run_cycle():
    mode = settings.get_mode()
    if mode == "auto":
        result = scheduler.run_auto_cycle()
        STATE["last_result"] = result
    else:
        # Even in manual mode, finished windows must free their units.
        result = {"released": scheduler.release_completed(), "attempted": 0, "scheduled": 0, "results": []}
    STATE["last_run"] = datetime.now(timezone.utc).isoformat()
    STATE["cycles"] += 1
    return result


async def loop():
    """Background task started with the API (see main.lifespan)."""
    while True:
        try:
            interval = max(1.0, settings.get_float("auto_interval_seconds", 5))
        except Exception:
            interval = 5.0
        await asyncio.sleep(interval)
        try:
            await asyncio.to_thread(_run_cycle)
            STATE["last_error"] = None
        except asyncio.CancelledError:
            raise
        except Exception as exc:                       # DB down etc.: keep the loop alive
            STATE["last_error"] = str(exc)
            log.warning("robo loop error: %s", exc)


def run_cycle_now():
    """Operator-triggered single auto pass (works in either mode)."""
    result = scheduler.run_auto_cycle(actor="operator")
    STATE["last_run"] = datetime.now(timezone.utc).isoformat()
    STATE["last_result"] = result
    return result


def manual_schedule(delivery_id, robot_id, actor="operator"):
    """Manual override: the operator picks the unit.  Capacity, availability,
    route and trip-battery safety checks still apply."""
    result = scheduler.schedule_delivery(delivery_id, mode="manual", forced_robot_id=robot_id, actor=actor)
    if not result["scheduled"]:
        raise ConflictError(result.get("reason", "Could not schedule"))
    return result


def status():
    counts = fetch_one(
        "SELECT (SELECT COUNT(*) FROM deliveries WHERE delivery_status = 'Pending')::int AS pending, "
        "(SELECT COUNT(*) FROM robot_schedule WHERE status = 'Running')::int AS running, "
        "(SELECT COUNT(*) FROM deliveries WHERE delivery_status = 'Delivered')::int AS delivered")
    return {
        "mode": settings.get_mode(),
        "interval_seconds": settings.get_float("auto_interval_seconds", 5),
        "last_run": STATE["last_run"],
        "cycles": STATE["cycles"],
        "last_error": STATE["last_error"],
        "pending": counts["pending"], "running": counts["running"], "delivered": counts["delivered"],
    }
