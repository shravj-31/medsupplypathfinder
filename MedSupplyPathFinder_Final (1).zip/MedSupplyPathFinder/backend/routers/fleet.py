from typing import Optional

from fastapi import APIRouter

from backend.schemas import RobotCreate, RobotUpdate
from backend.services import fleet, scheduler

router = APIRouter(tags=["Fleet Multi-Tenancy"])


@router.get("/robots/")
def list_robots(org_id: Optional[str] = None, status: Optional[str] = None):
    scheduler.release_completed()
    return fleet.list_robots(org_id, status)


@router.get("/robots/{robot_id}")
def get_robot(robot_id: str):
    return fleet.get_robot(robot_id)


@router.get("/fleet/summary")
def fleet_summary(org_id: Optional[str] = None):
    scheduler.release_completed()
    return fleet.fleet_summary(org_id)


@router.post("/fleet/robots", status_code=201)
def add_robot(body: RobotCreate):
    """Add a robot / drone node to an organization's fleet on the fly."""
    return fleet.add_robot(**body.model_dump())


@router.delete("/fleet/robots/{robot_id}")
def remove_robot(robot_id: str, force: bool = False):
    """Remove a node. A busy unit needs force=true (its delivery is re-queued)."""
    return fleet.remove_robot(robot_id, force)


@router.put("/fleet/robots/{robot_id}")
def update_robot(robot_id: str, body: RobotUpdate):
    return fleet.update_robot(robot_id, body.model_dump())
