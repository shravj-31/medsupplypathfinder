from typing import Optional

from fastapi import APIRouter

from backend.services import audit

router = APIRouter(prefix="/audit", tags=["Audit Log"])


@router.get("/")
def list_logs(limit: int = 100, entity_type: Optional[str] = None,
              action: Optional[str] = None, entity_id: Optional[str] = None):
    return audit.list_logs(min(max(limit, 1), 1000), entity_type, action, entity_id)
