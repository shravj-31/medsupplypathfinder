from fastapi import APIRouter

from backend.schemas import BlockRequest, CompareRequest, RouteRequest
from backend.services import routing

router = APIRouter(prefix="/routes", tags=["Routing"])


@router.post("/calculate")
def calculate(body: RouteRequest):
    return routing.calculate(body.source, body.destination, body.algorithm)


@router.post("/compare")
def compare(body: CompareRequest):
    """Dijkstra vs A*: distance, nodes explored, execution time."""
    return routing.compare(body.source, body.destination)


@router.get("/edges")
def edges():
    return routing.list_edges()


@router.put("/edges/block")
def block_edge(body: BlockRequest):
    """Block / unblock a corridor (both directions)."""
    return routing.set_edge_blocked(body.source, body.destination, body.blocked)
