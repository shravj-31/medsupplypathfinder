from fastapi import APIRouter

from backend.schemas import DomainRefresh, DomainUpdate
from backend.services import domains

router = APIRouter(prefix="/domains", tags=["Domain Configurations"])


@router.get("/")
def list_domains():
    return domains.list_domains()


@router.post("/refresh-names")
def refresh_names(body: DomainRefresh):
    """Dedicated action: regenerate domain names from the organization master."""
    return domains.refresh_domain_names(body.org_id, body.renames)


@router.put("/{domain_id}")
def update_domain(domain_id: str, body: DomainUpdate):
    return domains.update_domain(domain_id, body.domain_name, body.config, body.is_active)
