from typing import Optional

from fastapi import APIRouter

from backend.schemas import DeliveryCreate
from backend.services import deliveries, scheduler, settings

router = APIRouter(prefix="/deliveries", tags=["Deliveries"])


@router.get("/")
def list_deliveries(org_id: Optional[str] = None, status: Optional[str] = None):
    scheduler.release_completed()
    return deliveries.list_deliveries(org_id, status)


@router.get("/{delivery_id}")
def get_delivery(delivery_id: str):
    return deliveries.get_delivery(delivery_id)


@router.post("/", status_code=201)
def create_delivery(body: DeliveryCreate):
    """Create a task request. In Robo auto mode it is scheduled immediately."""
    created = deliveries.create_delivery(**body.model_dump())
    schedule = None
    if settings.get_mode() == "auto":
        try:
            schedule = scheduler.schedule_delivery(created["delivery_id"], "auto", None, "robo-auto")
        except Exception as exc:
            schedule = {"scheduled": False, "reason": str(exc)}
        created = deliveries.get_delivery(created["delivery_id"])
    return {"delivery": created, "auto_schedule": schedule}


@router.post("/{delivery_id}/complete")
def complete_delivery(delivery_id: str):
    """Demo helper: finish a running delivery now."""
    return scheduler.complete_now(delivery_id)


@router.post("/{delivery_id}/cancel")
def cancel_delivery(delivery_id: str):
    return scheduler.cancel_delivery(delivery_id)
