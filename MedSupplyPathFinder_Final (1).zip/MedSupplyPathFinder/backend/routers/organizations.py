from fastapi import APIRouter

from backend.schemas import OrgCreate, OrgUpdate
from backend.services import orgs

router = APIRouter(prefix="/organizations", tags=["Organization Master"])


@router.get("/")
def list_orgs():
    return orgs.list_orgs()


@router.get("/{org_id}")
def get_org(org_id: str):
    return orgs.get_org(org_id)


@router.post("/", status_code=201)
def create_org(body: OrgCreate):
    return orgs.create_org(body.org_id, body.org_name, body.org_type, body.contact_email)


@router.put("/{org_id}")
def update_org(org_id: str, body: OrgUpdate):
    return orgs.update_org(org_id, body.model_dump())


@router.delete("/{org_id}")
def delete_org(org_id: str):
    return orgs.delete_org(org_id)
