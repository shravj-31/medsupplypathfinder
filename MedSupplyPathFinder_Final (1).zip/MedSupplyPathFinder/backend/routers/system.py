from typing import Optional

from fastapi import APIRouter

from backend.database import fetch_one
from backend.services import dashboard, deliveries, routing

router = APIRouter()


@router.get("/health", tags=["System"])
def health():
    row = fetch_one("SELECT now() AS server_time")
    return {"status": "ok", "database": "connected", "server_time": row["server_time"]}


@router.get("/locations/", tags=["System"])
def locations():
    return routing.list_locations()


@router.get("/supplies/", tags=["System"])
def supplies():
    return deliveries.list_supplies()


@router.get("/dashboard/summary", tags=["System"])
def dashboard_summary(org_id: Optional[str] = None):
    return dashboard.summary(org_id)
