from typing import Optional

from fastapi import APIRouter

from backend.schemas import ManualSchedule, ModeUpdate, PreviewRequest
from backend.services import robo, scheduler, settings

router = APIRouter(prefix="/robo", tags=["Robo Mode"])


@router.get("/status")
def status():
    return robo.status()


@router.put("/mode")
def set_mode(body: ModeUpdate):
    """Switch between fully automated ('auto') and operator-driven ('manual')."""
    settings.set_mode(body.mode)
    return robo.status()


@router.post("/run-cycle")
def run_cycle():
    """Run one automatic scheduling pass right now."""
    return robo.run_cycle_now()


@router.post("/manual-schedule")
def manual_schedule(body: ManualSchedule):
    """Manual override: operator assigns a specific unit to a delivery."""
    return robo.manual_schedule(body.delivery_id, body.robot_id)


@router.post("/preview")
def preview(body: PreviewRequest):
    """Decision matrix for a hypothetical task (nothing is reserved)."""
    return scheduler.decision_matrix(body.org_id, body.weight_kg, body.source,
                                     body.destination, body.domain_id, body.priority)


@router.get("/timeline")
def timeline(org_id: Optional[str] = None, limit: int = 40):
    scheduler.release_completed()
    return scheduler.timeline(org_id, limit)
