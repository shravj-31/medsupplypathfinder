from typing import Any, Dict, Literal, Optional

from pydantic import BaseModel, Field

Priority = Literal["Critical", "High", "Medium", "Low"]


class OrgCreate(BaseModel):
    org_id: str = Field(pattern=r"^[A-Za-z0-9_-]{3,20}$", description="Custom ID, e.g. ORG-003")
    org_name: str = Field(min_length=2, max_length=100)
    org_type: str = "Hospital"
    contact_email: Optional[str] = None


class OrgUpdate(BaseModel):
    org_name: Optional[str] = Field(default=None, min_length=2, max_length=100)
    org_type: Optional[str] = None
    contact_email: Optional[str] = None
    is_active: Optional[bool] = None


class RobotCreate(BaseModel):
    org_id: str
    robot_type: Literal["Robot", "Drone"] = "Robot"
    robot_id: Optional[str] = Field(default=None, description="Leave empty to auto-generate")
    battery_percentage: int = Field(default=100, ge=0, le=100)
    load_capacity_kg: float = Field(gt=0, le=1000)
    base_speed_mps: float = Field(default=1.5, gt=0, le=50)
    current_location: str = "Pharmacy"
    robot_status: Literal["Available", "Charging", "Offline", "Maintenance"] = "Available"


class RobotUpdate(BaseModel):
    robot_status: Optional[Literal["Available", "Charging", "Offline", "Maintenance"]] = None
    battery_percentage: Optional[int] = Field(default=None, ge=0, le=100)
    load_capacity_kg: Optional[float] = Field(default=None, gt=0, le=1000)
    base_speed_mps: Optional[float] = Field(default=None, gt=0, le=50)
    current_location: Optional[str] = None


class DeliveryCreate(BaseModel):
    supply_id: str
    source: str
    destination: str
    weight_kg: float = Field(gt=0, le=1000, description="wt - payload weight in kg")
    quantity: int = Field(default=1, ge=1)
    priority: Priority = "Medium"
    org_id: Optional[str] = None
    domain_id: Optional[str] = None


class RouteRequest(BaseModel):
    source: str
    destination: str
    algorithm: str = "astar"


class CompareRequest(BaseModel):
    source: str
    destination: str


class BlockRequest(BaseModel):
    source: str
    destination: str
    blocked: bool = True


class PreviewRequest(BaseModel):
    org_id: str
    weight_kg: float = Field(gt=0, le=1000)
    source: str
    destination: str
    domain_id: Optional[str] = None
    priority: Priority = "Medium"


class ManualSchedule(BaseModel):
    delivery_id: str
    robot_id: str


class ModeUpdate(BaseModel):
    mode: Literal["auto", "manual"]


class DomainUpdate(BaseModel):
    domain_name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class DomainRefresh(BaseModel):
    org_id: Optional[str] = None
    renames: Optional[Dict[str, str]] = None
