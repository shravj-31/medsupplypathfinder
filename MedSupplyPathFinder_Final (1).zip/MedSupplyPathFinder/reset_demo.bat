@echo off
REM Reset the database to the clean demo state (run before presenting)
cd /d %~dp0
if exist venv\Scripts\activate call venv\Scripts\activate
python scripts\init_db.py
pause
