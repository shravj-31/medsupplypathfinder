from algorithms.graph import Graph

LOCS = [(1, "Pharmacy", 10, 10), (2, "Blood Bank", 10, 50), (3, "Ward A", 60, 10), (4, "ICU", 80, 20),
        (5, "Laboratory", 90, 60), (6, "Surgery", 60, 70), (7, "Elevator 1", 40, 20), (8, "Emergency Dock", 70, 30)]
EDGES = [(1, 3, 50), (3, 4, 20), (4, 5, 30), (1, 7, 35), (7, 4, 25), (2, 6, 40), (6, 4, 35),
         (3, 6, 65), (1, 2, 45), (4, 8, 15), (8, 6, 30), (5, 6, 25)]


def hospital_graph(blocked=()):
    g = Graph()
    for i, n, x, y in LOCS:
        g.add_node(i, n, x, y)
    for a, b, d in EDGES:
        if (a, b) in blocked or (b, a) in blocked:
            continue
        g.add_edge(a, b, d)
        g.add_edge(b, a, d)
    return g
