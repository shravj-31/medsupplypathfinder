"""API integration tests.  Need PostgreSQL with sql/schema.sql loaded (python scripts/init_db.py).
They are skipped automatically when the database is not reachable."""
import pytest

try:
    from fastapi.testclient import TestClient
    from backend.database import fetch_one
    from backend.main import app
    fetch_one("SELECT 1 AS ok")
    DB_OK = True
except Exception:                       # no DB / no httpx
    DB_OK = False

pytestmark = pytest.mark.skipif(not DB_OK, reason="database not reachable")


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health(client):
    assert client.get("/api/health").json()["status"] == "ok"


def test_route_dijkstra_and_astar_agree(client):
    a = client.post("/api/routes/calculate", json={"source": "Pharmacy", "destination": "ICU", "algorithm": "dijkstra"}).json()
    b = client.post("/api/routes/calculate", json={"source": "Pharmacy", "destination": "ICU", "algorithm": "astar"}).json()
    assert a["distance_meters"] == b["distance_meters"]


def test_invalid_location(client):
    r = client.post("/api/routes/calculate", json={"source": "Nowhere", "destination": "ICU"})
    assert r.status_code == 404


def test_preview_capacity_check(client):
    r = client.post("/api/robo/preview", json={"org_id": "ORG-001", "weight_kg": 99,
                                               "source": "Pharmacy", "destination": "ICU"}).json()
    assert r["selected_robot"] is None and r["pool"]["capacity_ok"] == 0


def test_fleet_add_and_remove(client):
    r = client.post("/api/fleet/robots", json={"org_id": "ORG-001", "robot_id": "TST001", "load_capacity_kg": 4})
    assert r.status_code == 201
    assert client.delete("/api/fleet/robots/TST001").status_code == 200
    assert client.delete("/api/fleet/robots/TST001").status_code == 404


def test_org_custom_id_validation(client):
    assert client.post("/api/organizations/", json={"org_id": "x", "org_name": "Bad"}).status_code == 422


def test_domain_refresh(client):
    r = client.post("/api/domains/refresh-names", json={"org_id": "ORG-001"})
    assert r.status_code == 200 and len(r.json()["domains"]) == 3
