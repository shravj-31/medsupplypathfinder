from algorithms.astar import astar
from algorithms.dijkstra import dijkstra
from tests.helpers import hospital_graph

PHARMACY, WARD_A, ICU, LAB, SURGERY, ELEVATOR, BLOOD = 1, 3, 4, 5, 6, 7, 2


def names(g, res):
    return [g.name(i) for i in res.path]


def test_dijkstra_shortest_is_via_elevator():
    g = hospital_graph()
    r = dijkstra(g, PHARMACY, ICU)
    assert r.distance == 60 and names(g, r) == ["Pharmacy", "Elevator 1", "ICU"]


def test_alternative_route_when_elevator_corridor_blocked():
    g = hospital_graph(blocked=[(ELEVATOR, ICU)])
    for fn in (dijkstra, astar):
        r = fn(g, PHARMACY, ICU)
        assert r.distance == 70 and names(g, r) == ["Pharmacy", "Ward A", "ICU"]


def test_astar_matches_dijkstra_for_every_pair():
    g = hospital_graph()
    for a in g.nodes:
        for b in g.nodes:
            if a != b:
                assert astar(g, a, b).distance == dijkstra(g, a, b).distance


def test_astar_explores_no_more_nodes():
    g = hospital_graph()
    d, a = dijkstra(g, PHARMACY, LAB), astar(g, PHARMACY, LAB)
    assert a.nodes_explored <= d.nodes_explored


def test_unreachable_returns_none():
    g = hospital_graph(blocked=[(PHARMACY, WARD_A), (PHARMACY, ELEVATOR), (PHARMACY, BLOOD)])
    assert dijkstra(g, PHARMACY, ICU) is None and astar(g, PHARMACY, ICU) is None


def test_unknown_node_returns_none():
    assert dijkstra(hospital_graph(), 1, 999) is None
