"""Decision-matrix engine: pure unit tests (no database needed)."""
from backend.services.domains import DynamicDomain, EmergencyDomain, MedicalDomain
from backend.services.engine import (SchedParams, build_matrix, estimate_time,
                                     payload_coefficient)


def robot(rid, cap=10, battery=90, status="Available", avail=True, speed=1.5, rtype="Robot"):
    return {"robot_id": rid, "robot_type": rtype, "robot_status": status, "is_available": avail,
            "battery_percentage": battery, "load_capacity_kg": cap, "base_speed_mps": speed,
            "current_location_name": "Pharmacy"}


def test_payload_coefficient_grows_with_weight():
    assert payload_coefficient(0, 10) == 1.0
    assert payload_coefficient(10, 10) == 1.6
    assert payload_coefficient(5, 10) < payload_coefficient(8, 10)


def test_time_estimate_formula():
    e = estimate_time(0, 60, 1.5, 1.5, 10, 1.0, SchedParams())
    assert e["payload_coeff"] == 1.09
    assert round(e["total_s"], 1) == 53.6          # 60*1.09/1.5 + 10 s handling


def test_heavier_payload_takes_longer():
    light = estimate_time(10, 60, 1.5, 1, 10)["total_s"]
    heavy = estimate_time(10, 60, 1.5, 9, 10)["total_s"]
    assert heavy > light


def test_capacity_check_drops_unit():
    robots = [robot("A", cap=3), robot("B", cap=12)]
    rows, win = build_matrix(robots, 6.0, {"A": (0, 60), "B": (0, 60)}, MedicalDomain("m", "m"))
    assert win["robot_id"] == "B"
    a = next(r for r in rows if r["robot_id"] == "A")
    assert not a["capacity_ok"] and "Over capacity" in a["reason"]


def test_wt_equal_to_capacity_is_allowed():
    rows, win = build_matrix([robot("A", cap=6)], 6.0, {"A": (0, 40)}, EmergencyDomain("e", "e"))
    assert win and win["robot_id"] == "A"


def test_availability_filter():
    robots = [robot("A", status="Charging", avail=False), robot("B", status="Active", avail=False)]
    rows, win = build_matrix(robots, 1.0, {"A": (0, 40), "B": (0, 40)}, EmergencyDomain("e", "e"))
    assert win is None and all(not r["availability_ok"] for r in rows)


def test_no_route_drops_unit():
    rows, win = build_matrix([robot("A")], 1.0, {"A": (None, None)}, EmergencyDomain("e", "e"))
    assert win is None and rows[0]["reason"].startswith("No route")


def test_emergency_picks_fastest():
    robots = [robot("SLOW", speed=1.0), robot("FAST", speed=4.0)]
    d = {"SLOW": (0, 60), "FAST": (0, 60)}
    assert build_matrix(robots, 1.0, d, EmergencyDomain("e", "e"))[1]["robot_id"] == "FAST"


def test_medical_requires_30_percent_battery():
    rows, win = build_matrix([robot("A", battery=25)], 1.0, {"A": (0, 40)}, MedicalDomain("m", "m"))
    assert win is None and "below Medical minimum" in rows[0]["reason"]
    rows, win = build_matrix([robot("A", battery=25)], 1.0, {"A": (0, 40)}, EmergencyDomain("e", "e"))
    assert win is not None          # emergency floor is 15 %


def test_dynamic_ranks_and_adapts_to_queue_pressure():
    robots = [robot("FASTLOW", speed=3.0, battery=40), robot("SLOWFULL", speed=1.2, battery=99)]
    d = {"FASTLOW": (0, 80), "SLOWFULL": (0, 80)}
    dom = DynamicDomain("d", "d")
    calm = build_matrix(robots, 1.0, d, dom, {"pending_count": 0})[1]["robot_id"]
    busy = build_matrix(robots, 1.0, d, dom, {"pending_count": 10})[1]["robot_id"]
    assert busy == "FASTLOW"          # long queue -> speed matters most
    assert calm in ("FASTLOW", "SLOWFULL")


def test_trip_battery_reserve():
    rows, win = build_matrix([robot("A", battery=30)], 1.0, {"A": (0, 500)}, EmergencyDomain("e", "e"))
    assert win is None and rows[0]["reason"] == "Battery too low for this trip"
