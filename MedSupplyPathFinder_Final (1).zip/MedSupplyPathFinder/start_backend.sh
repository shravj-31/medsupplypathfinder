#!/usr/bin/env bash
cd "$(dirname "$0")"; [ -d venv ] && . venv/bin/activate
python -m uvicorn backend.main:app --reload --port 8000
