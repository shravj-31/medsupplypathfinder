"""Dijkstra's shortest path (no heuristic)."""
import heapq
import time
from typing import Optional

from algorithms.graph import Graph, RouteResult


def dijkstra(graph: Graph, source: int, target: int) -> Optional[RouteResult]:
    if source not in graph.nodes or target not in graph.nodes:
        return None
    t0 = time.perf_counter()
    dist = {source: 0.0}
    prev = {}
    heap = [(0.0, source)]
    settled = set()
    while heap:
        d, u = heapq.heappop(heap)
        if u in settled:
            continue
        settled.add(u)
        if u == target:
            break
        for v, w in graph.adj[u]:
            nd = d + w
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, v))
    if target not in dist:
        return None
    path = [target]
    while path[-1] != source:
        path.append(prev[path[-1]])
    path.reverse()
    return RouteResult("Dijkstra", path, round(dist[target], 3), len(settled),
                       round((time.perf_counter() - t0) * 1000, 4))
