"""Hospital graph: database rows -> Python graph used by Dijkstra and A*."""
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class RouteResult:
    algorithm: str
    path: List[int]            # location ids in order
    distance: float            # meters
    nodes_explored: int
    execution_ms: float


class Graph:
    def __init__(self):
        self.nodes: Dict[int, dict] = {}                 # id -> {name, x, y}
        self.adj: Dict[int, List[Tuple[int, float]]] = {}
        self._ratio: Optional[float] = None

    # ---- building -------------------------------------------------
    def add_node(self, node_id, name, x=None, y=None):
        self.nodes[node_id] = {"name": name, "x": x, "y": y}
        self.adj.setdefault(node_id, [])
        self._ratio = None

    def add_edge(self, src, dst, distance):
        if src in self.nodes and dst in self.nodes:
            self.adj[src].append((dst, float(distance)))
            self._ratio = None

    @classmethod
    def from_rows(cls, locations, edges):
        """locations: rows with location_id, location_name, x_coordinate,
        y_coordinate, is_accessible.  edges: rows with source_location,
        destination_location, distance_meters (already excluding blocked)."""
        g = cls()
        for r in locations:
            if r.get("is_accessible", True) is False:
                continue
            g.add_node(r["location_id"], r["location_name"],
                       r.get("x_coordinate"), r.get("y_coordinate"))
        for e in edges:
            g.add_edge(e["source_location"], e["destination_location"],
                       e["distance_meters"])
        return g

    # ---- helpers --------------------------------------------------
    def name(self, node_id):
        return self.nodes[node_id]["name"]

    def euclid(self, a, b):
        na, nb = self.nodes[a], self.nodes[b]
        if None in (na["x"], na["y"], nb["x"], nb["y"]):
            return 0.0
        return math.hypot(na["x"] - nb["x"], na["y"] - nb["y"])

    def heuristic_scale(self):
        """Edge lengths in the database can be shorter than the straight-line
        distance between coordinates.  Scaling the Euclidean heuristic by the
        smallest (edge length / straight line) ratio keeps it admissible, so
        A* is guaranteed to return the same optimal distance as Dijkstra."""
        if self._ratio is None:
            ratio = 1.0
            for a, nbrs in self.adj.items():
                for b, d in nbrs:
                    e = self.euclid(a, b)
                    if e > 0:
                        ratio = min(ratio, d / e)
            self._ratio = ratio
        return self._ratio

    def heuristic(self, a, b):
        return self.euclid(a, b) * self.heuristic_scale()
