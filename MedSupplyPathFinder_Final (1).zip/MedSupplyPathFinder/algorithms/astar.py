"""A* shortest path: f(n) = g(n) + h(n), h = scaled Euclidean distance."""
import heapq
import time
from typing import Optional

from algorithms.graph import Graph, RouteResult


def astar(graph: Graph, source: int, target: int) -> Optional[RouteResult]:
    if source not in graph.nodes or target not in graph.nodes:
        return None
    t0 = time.perf_counter()
    g = {source: 0.0}
    prev = {}
    heap = [(graph.heuristic(source, target), source)]
    closed = set()
    while heap:
        _, u = heapq.heappop(heap)
        if u in closed:
            continue
        closed.add(u)
        if u == target:
            break
        for v, w in graph.adj[u]:
            ng = g[u] + w
            if ng < g.get(v, float("inf")):
                g[v] = ng
                prev[v] = u
                heapq.heappush(heap, (ng + graph.heuristic(v, target), v))
    if target not in g:
        return None
    path = [target]
    while path[-1] != source:
        path.append(prev[path[-1]])
    path.reverse()
    return RouteResult("A*", path, round(g[target], 3), len(closed),
                       round((time.perf_counter() - t0) * 1000, 4))
