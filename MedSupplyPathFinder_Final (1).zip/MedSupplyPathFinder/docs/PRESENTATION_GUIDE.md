# Presentation guide - Med-Supply PathFinder

## 1. The 30-second pitch
"Hospitals lose minutes moving blood, medicine and samples. Med-Supply PathFinder assigns each
delivery to the *right* robot or drone and finds the shortest safe route. For every task it checks
weight against capacity, availability, battery and route, estimates the time with a payload-aware
formula, reserves that time on the unit's timeline, and can run fully automatically (Robo Mode) or
under operator control."

## 2. Roadmap (say this as the project story)
| Phase | Status | What |
|---|---|---|
| 1. Data model | Done | PostgreSQL: locations, graph edges, robots, supplies, deliveries |
| 2. Backend API | Done | FastAPI + psycopg + Pydantic validation |
| 3. Routing | Done | Dijkstra and A\* on the hospital graph, blocked corridors, algorithm comparison |
| 4. Multi-attribute fleet allocation | Done (this release) | wt, Capacity, Availability, No. of Robots -> decision matrix, time estimation, time reservation |
| 5. Platform features | Done (this release) | Organization master, audit log, fleet add/remove, domains (Emergency/Medical/Dynamic Set A), Robo Mode auto + manual override |
| 6. Next | Future work | ML delivery-time prediction (scikit-learn RandomForest trained on the audit log), live traffic and alerts, multi-floor digital-twin map, authentication/roles, per-organization maps, SDG 3/9/11 reporting |

Be honest that item 6 is future work - the workflow document lists ML, digital twin and SDG
dashboards; they are *not* in this release.

## 3. Suggested slides (about 10 minutes)
1. **Problem** - delays in hospital logistics; manual dispatch.
2. **Solution + architecture** - Streamlit -> FastAPI -> PostgreSQL diagram.
3. **Data model** - 10 tables; organizations own robots and deliveries.
4. **Routing** - Dijkstra vs A\*; nodes explored; blocked-corridor re-routing.
5. **The decision matrix** - the four inputs (wt, Capacity, Availability, No. of Robots) and the 7-step pipeline.
6. **Time estimation formula** - empty leg + loaded leg x payload coefficient + handling; reservation on the timeline.
7. **Domains** - Emergency (fastest), Medical (gentle/safe), Dynamic Set A (balanced, adapts to queue).
8. **Robo Mode** - automatic vs manual override.
9. **Live demo** (below).
10. **Results, limitations, future work.**

## 4. Live demo script (start from `reset_demo.bat`; refresh the browser)
Expected numbers come from the seeded data.

1. **Dashboard** - 7 robots across 2 organizations (pick ORG-001: 5 units), 5 Pending deliveries, Robo Mode MANUAL.
   *Say:* RB002 is Charging and RB004 is in Maintenance, so they are not available.
2. **Decision Matrix** (ORG-001). wt = 2.0, Blood Bank -> ICU, priority Critical, domain Auto.
   Winner **DR001** (drone, ETA 45 s). RB002 / RB004 dropped as *Unavailable*.
   Change wt to **14** -> "Capacity OK = 0", nobody selected: every unit fails `wt <= Capacity`.
3. **Same task, three domains** (wt 1.5, Pharmacy -> ICU): Emergency picks **DR001** (40.6 s, fastest);
   Medical picks **RB001** (53.6 s - avoids loading the small drone to 50 %); Dynamic picks **RB001**.
   *Say:* same fleet, different routing class, different decision.
4. **Route Optimizer** - Pharmacy -> ICU = **60 m** via Elevator 1. Compare Dijkstra vs A\*: Pharmacy -> Laboratory
   = 90 m for both, nodes explored 8 vs 5. Block *Elevator 1 <-> ICU* -> route becomes **70 m** via Ward A.
   Unblock it afterwards.
5. **Robo Mode, manual override** - choose DEL002 + RB002 -> rejected (Charging). Choose RB001 -> accepted,
   reserved **53.6 s**; the timeline bar appears and RB001 turns *Active* on the Dashboard.
   Try DEL003 on RB001 -> rejected (busy). Try DEL005 (14 kg) on any unit -> capacity check fails.
6. **Robo Mode, automatic** - switch to *Automated*, Apply, press *Run one automatic scheduling pass*.
   DEL001 (Critical) goes to DR001 first, DEL004 to RB003; DEL003 waits (all units busy) and DEL005 stays Pending
   because it exceeds every capacity. Open Deliveries and click *Complete now* on a running task - the unit is
   freed, moved to the destination, battery reduced, and the next pass assigns DEL003 automatically.
   (With Auto-refresh ticked in the sidebar the background loop does this by itself every 5 s.)
7. **Fleet** - add a Drone (capacity 5 kg) to ORG-001 -> appears instantly in the pool count; remove it.
   Switch organization to ORG-002 to show multi-tenancy (separate fleet of 2).
8. **Domains** - press *Refresh domain names* (names regenerate from the Organization Master).
9. **Audit Log** - show the timestamped trail of everything you just did.

## 5. Requirement -> proof
| Requirement | Where to show it |
|---|---|
| wt <= Capacity check | Decision Matrix with wt = 14 |
| Availability filter | RB002 Charging / RB004 Maintenance dropped |
| No. of Robots | Fleet and Decision Matrix metrics (pool size per organization) |
| Time = distance, base speed, payload coefficient | Winner banner: empty leg + loaded leg + handling, payload coefficient |
| Reserve duration, shift Availability | Robo Mode timeline + robot turns Active, frees after the window |
| Organization master | Organizations page (custom IDs ORG-001, ORG-002; try creating ORG-003) |
| Timestamps / audit | Audit Log page; `created_at` / `updated_at` everywhere |
| Fleet add/remove | Fleet page, Swagger `POST/DELETE /api/fleet/robots` |
| Emergency / Medical / Dynamic + refresh | Domains page and step 3 |
| Robo Mode auto + manual override | Robo Mode page |

## 6. Likely questions
* **Why A\* if Dijkstra is correct?** Same optimal distance, fewer nodes explored (8 vs 5 here); the gap grows on big maps.
* **Is A\* guaranteed optimal?** Yes - the heuristic is scaled so it never overestimates; a test checks every node pair.
* **Why does a heavier payload take longer?** Coefficient `1 + 0.6 x wt/Capacity`: 0 % extra empty, 60 % extra at full load.
* **What if two requests want the same robot?** A lock plus a unique "one running reservation per robot" database index.
* **What happens when a corridor is blocked mid-delivery?** In-flight tasks keep their reservation; new tasks use the new graph (limitation).
* **Is this real robot control?** No - it is the scheduling/optimisation layer; time is simulated against the clock.
* **Where is the AI?** Not claimed. ML delivery-time prediction is the next phase (audit log = training data).

## 7. Checklist for tomorrow
- [ ] PostgreSQL running; `.env` password correct
- [ ] `setup.bat` already run once; then `reset_demo.bat` just before presenting
- [ ] `start_backend.bat` and `start_frontend.bat` in two windows
- [ ] `python scripts/smoke_test.py` -> all checks PASS (then `reset_demo.bat` again)
- [ ] Open http://127.0.0.1:8000/docs in a tab as backup (Swagger can run every demo step)
- [ ] Screenshots of each page saved as a fallback if the laptop misbehaves
