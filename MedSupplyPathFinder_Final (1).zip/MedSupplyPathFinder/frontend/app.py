"""Med-Supply PathFinder - Streamlit front end.

Run:  streamlit run frontend/app.py
"""
import json
import time
from datetime import datetime, timezone

import pandas as pd
import streamlit as st

import api
from api import ApiError

try:
    import plotly.express as px
    import plotly.graph_objects as go
except Exception:                                   # plotly is optional; tables are the fallback
    px = go = None

st.set_page_config(page_title="Med-Supply PathFinder", page_icon="🏥", layout="wide")

PAGES = ["Dashboard", "Robo Mode", "Decision Matrix", "Deliveries", "Fleet",
         "Organizations", "Domains", "Route Optimizer", "Audit Log"]
STATUS_COLORS = {"Available": "#2e9e5b", "Active": "#2f6fd6", "Charging": "#e0a100",
                 "Offline": "#8a8f98", "Maintenance": "#d64545"}


# ----------------------------------------------------------------- helpers
def safe(fn, *args, **kwargs):
    """Call the API; show the error in the UI instead of crashing."""
    try:
        return fn(*args, **kwargs)
    except ApiError as exc:
        st.error(str(exc))
        return None


def flash(kind, message):
    st.session_state["flash"] = (kind, message)


def show_flash():
    item = st.session_state.pop("flash", None)
    if item:
        getattr(st, item[0])(item[1])


def show_df(df):
    try:
        st.dataframe(df, width="stretch", hide_index=True)
    except Exception:
        st.dataframe(df, use_container_width=True, hide_index=True)


def show_chart(fig):
    try:
        st.plotly_chart(fig, width="stretch")
    except Exception:
        st.plotly_chart(fig, use_container_width=True)


def fmt_seconds(value):
    if value is None:
        return "-"
    value = float(value)
    if value < 60:
        return "%.0f s" % value
    return "%dm %02ds" % (value // 60, value % 60)


def table(rows, columns, rename=None):
    if not rows:
        st.info("Nothing to show yet.")
        return
    df = pd.DataFrame(rows)
    cols = [c for c in columns if c in df.columns]
    df = df[cols]
    if rename:
        df = df.rename(columns=rename)
    show_df(df)


def load(endpoint, params=None):
    return safe(api.get_data, endpoint, params)


def org_options():
    orgs = load("/api/organizations/") or []
    return orgs


# ------------------------------------------------------------------- pages
def page_dashboard(org_id):
    st.subheader("Operations Dashboard")
    summary = load("/api/dashboard/summary", {"org_id": org_id} if org_id else None)
    fleet = load("/api/fleet/summary", {"org_id": org_id} if org_id else None)
    robots = load("/api/robots/", {"org_id": org_id} if org_id else None)
    deliveries = load("/api/deliveries/", {"org_id": org_id} if org_id else None)
    if summary is None or robots is None or deliveries is None:
        return

    c = st.columns(6)
    c[0].metric("Total Deliveries", summary["total_deliveries"])
    c[1].metric("Active Robots", summary["active_robots"])
    c[2].metric("Emergency Deliveries", summary["emergency_deliveries"])
    c[3].metric("Active Routes", summary["active_routes"])
    c[4].metric("Avg Delivery Time", fmt_seconds(summary["avg_delivery_seconds"]))
    c[5].metric("Pending", summary["pending_deliveries"])

    if fleet:
        f = st.columns(4)
        f[0].metric("No. of Robots (pool)", fleet["no_of_robots"])
        f[1].metric("Available now", fleet["available"])
        f[2].metric("Largest unit capacity", "%s kg" % fleet["max_unit_capacity_kg"])
        f[3].metric("Robo Mode", summary["robo_mode"].upper())

    left, right = st.columns([3, 2])
    with left:
        st.markdown("**Robot status**")
        table(robots, ["robot_id", "org_id", "robot_type", "robot_status", "is_available", "battery_percentage",
                       "load_capacity_kg", "base_speed_mps", "current_location_name", "current_delivery",
                       "seconds_remaining"],
              {"robot_status": "status", "is_available": "available", "battery_percentage": "battery %",
               "load_capacity_kg": "capacity kg", "base_speed_mps": "speed m/s",
               "current_location_name": "location", "seconds_remaining": "busy for (s)"})
    with right:
        st.markdown("**Battery by unit**")
        if px is not None and robots:
            df = pd.DataFrame(robots)
            fig = px.bar(df, x="robot_id", y="battery_percentage", color="robot_status",
                         color_discrete_map=STATUS_COLORS, range_y=[0, 100])
            fig.update_layout(height=300, margin=dict(l=10, r=10, t=10, b=10), xaxis_title=None,
                              yaxis_title="battery %")
            show_chart(fig)

    st.markdown("**Active deliveries**")
    active = [d for d in deliveries if d["delivery_status"] in ("In Transit", "Assigned")]
    table(active, ["delivery_id", "priority", "source", "destination", "weight_kg", "assigned_robot",
                   "route_path", "est_duration_seconds", "seconds_remaining", "schedule_mode"],
          {"weight_kg": "wt kg", "est_duration_seconds": "ETA s", "seconds_remaining": "remaining s",
           "schedule_mode": "mode"})
    st.markdown("**All deliveries**")
    table(deliveries, ["delivery_id", "priority", "delivery_status", "source", "destination", "weight_kg",
                       "assigned_robot", "domain_id", "algorithm_used", "route_distance_m", "schedule_note"],
          {"weight_kg": "wt kg", "delivery_status": "status", "route_distance_m": "distance m"})


def draw_timeline(rows):
    if not rows:
        st.info("No scheduled tasks yet. Create a delivery and schedule it.")
        return
    df = pd.DataFrame(rows)
    if px is None:
        table(rows, ["robot_id", "delivery_id", "start_time", "end_time", "duration_seconds", "status", "mode"])
        return
    df["start"] = pd.to_datetime(df["start_time"], utc=True)
    df["end"] = pd.to_datetime(df["end_time"], utc=True)
    df["task"] = df["delivery_id"]
    fig = px.timeline(df, x_start="start", x_end="end", y="robot_id", color="status", text="task",
                      color_discrete_map={"Running": "#2f6fd6", "Completed": "#2e9e5b", "Cancelled": "#8a8f98"})
    fig.update_yaxes(autorange="reversed", title=None)
    fig.update_layout(height=60 * max(df["robot_id"].nunique(), 3) + 90, margin=dict(l=10, r=10, t=10, b=10))
    try:
        now = datetime.now(timezone.utc).isoformat()
        fig.add_shape(type="line", x0=now, x1=now, y0=0, y1=1, yref="paper",
                      line=dict(color="#d64545", dash="dot", width=2))
    except Exception:
        pass
    show_chart(fig)


def page_robo(org_id):
    st.subheader("Robo Mode")
    status = load("/api/robo/status")
    if status is None:
        return
    c = st.columns(5)
    c[0].metric("Mode", status["mode"].upper())
    c[1].metric("Pending tasks", status["pending"])
    c[2].metric("Running tasks", status["running"])
    c[3].metric("Delivered", status["delivered"])
    c[4].metric("Auto interval", "%ss" % int(status["interval_seconds"]))

    st.markdown("#### 1. Operating mode")
    col1, col2 = st.columns([2, 3])
    with col1:
        choice = st.radio("Dual operational setting",
                          ["auto", "manual"], index=0 if status["mode"] == "auto" else 1,
                          format_func=lambda m: "Automated (background scheduling)" if m == "auto"
                          else "Manual (operator override)", key="mode_choice")
        if st.button("Apply mode", type="primary"):
            if safe(api.put, "/api/robo/mode", {"mode": choice}) is not None:
                flash("success", "Robo Mode is now %s." % choice.upper())
                st.rerun()
    with col2:
        st.caption("**Automated:** a background loop picks up every Pending delivery in priority order "
                   "(Critical > High > Medium > Low), runs the decision matrix and reserves the winning "
                   "unit's time window. **Manual:** nothing is scheduled until the operator assigns a unit below.")
        if st.button("Run one automatic scheduling pass now"):
            res = safe(api.post, "/api/robo/run-cycle")
            if res is not None:
                flash("success", "Pass finished: %d attempted, %d scheduled, %d released."
                      % (res["attempted"], res["scheduled"], len(res["released"])))
                st.rerun()

    st.markdown("#### 2. Unit timelines (reserved windows)")
    draw_timeline(load("/api/robo/timeline", {"org_id": org_id, "limit": 40} if org_id else {"limit": 40}))

    st.markdown("#### 3. Manual override - direct operator scheduling")
    pending = load("/api/deliveries/", {"org_id": org_id, "status": "Pending"} if org_id else {"status": "Pending"})
    robots = load("/api/robots/", {"org_id": org_id} if org_id else None)
    if not pending:
        st.info("No Pending deliveries. Create one on the Deliveries page.")
    elif robots:
        d_map = {"%s | %s | %s -> %s | wt %s kg" % (d["delivery_id"], d["priority"], d["source"],
                                                    d["destination"], d["weight_kg"]): d for d in pending}
        d_key = st.selectbox("Pending delivery", list(d_map.keys()), key="man_delivery")
        chosen = d_map[d_key]
        usable = [r for r in robots if r["org_id"] == chosen["org_id"]]
        r_map = {"%s | %s | cap %s kg | %s%s | %s%%" % (
            r["robot_id"], r["robot_type"], r["load_capacity_kg"], r["robot_status"],
            "" if r["is_available"] else " (not available)", r["battery_percentage"]): r for r in usable}
        if not r_map:
            st.warning("Organization %s has no robots." % chosen["org_id"])
        else:
            r_key = st.selectbox("Unit", list(r_map.keys()), key="man_robot")
            if st.button("Schedule with this unit", type="primary", key="man_go"):
                res = safe(api.post, "/api/robo/manual-schedule",
                           {"delivery_id": chosen["delivery_id"], "robot_id": r_map[r_key]["robot_id"]})
                if res is not None:
                    e = res["estimate"]
                    flash("success", "%s assigned to %s. Reserved %s (empty leg %ss + loaded leg %ss + handling %ss; "
                                     "payload coefficient %s)." % (
                              res["robot_id"], res["delivery_id"], fmt_seconds(res["window"]["duration_seconds"]),
                              e["empty_leg_s"], e["loaded_leg_s"], e["handling_s"], e["payload_coeff"]))
                    st.rerun()
            st.caption("Safety checks still apply in manual mode: wt <= Capacity, unit available, route exists, "
                       "enough battery for the trip.")


def page_matrix(org_id):
    st.subheader("Decision Matrix (what-if)")
    st.caption("Enter a task and see exactly how the engine filters and ranks the fleet. Nothing is reserved.")
    locs = [l["location_name"] for l in (load("/api/locations/") or [])]
    domains = load("/api/domains/") or []
    if not locs or not org_id:
        st.info("Select an organization in the sidebar.")
        return
    c = st.columns(5)
    wt = c[0].number_input("wt - payload weight (kg)", min_value=0.1, max_value=100.0, value=2.0, step=0.5)
    src = c[1].selectbox("Pickup", locs, index=min(1, len(locs) - 1))
    dst = c[2].selectbox("Destination", locs, index=3 if len(locs) > 3 else 0)
    priority = c[3].selectbox("Priority", ["Critical", "High", "Medium", "Low"], index=2)
    dom_map = {"Auto (by priority)": None}
    dom_map.update({"%s [%s]" % (d["domain_name"], d["domain_id"]): d["domain_id"] for d in domains if d["is_active"]})
    dom_label = c[4].selectbox("Domain", list(dom_map.keys()))
    if st.button("Run decision matrix", type="primary"):
        res = safe(api.post, "/api/robo/preview", {"org_id": org_id, "weight_kg": wt, "source": src,
                                                    "destination": dst, "domain_id": dom_map[dom_label],
                                                    "priority": priority})
        st.session_state["matrix_result"] = res
    res = st.session_state.get("matrix_result")
    if not res:
        return
    p = res["pool"]
    m = st.columns(5)
    m[0].metric("No. of Robots", p["no_of_robots"])
    m[1].metric("Availability OK", p["available"])
    m[2].metric("Capacity OK (wt <= cap)", p["capacity_ok"])
    m[3].metric("Eligible", p["eligible"])
    m[4].metric("Selected", res["selected_robot"] or "none")
    st.write("**Domain:** %s (%s)" % (res["domain"]["name"], res["domain"]["routing_class"]))
    if res["route"]:
        st.write("**Route:** %s  |  %s m" % (" -> ".join(res["route"]["path"]), res["route"]["distance_meters"]))
    else:
        st.warning("No route between pickup and destination (blocked corridors).")
    rows = res["matrix"]
    for r in rows:
        r["verdict"] = "SELECTED" if r["selected"] else ("eligible" if r["eligible"] else "dropped")
    table(rows, ["rank", "robot_id", "robot_type", "status", "location", "availability_ok", "capacity_kg", "wt_kg",
                 "capacity_ok", "battery", "dist_to_pickup_m", "dist_delivery_m", "eta_seconds", "score",
                 "verdict", "reason"],
          {"availability_ok": "available", "capacity_kg": "capacity kg", "wt_kg": "wt kg",
           "capacity_ok": "wt <= cap", "dist_to_pickup_m": "to pickup m", "dist_delivery_m": "delivery m",
           "eta_seconds": "ETA s"})
    best = next((r for r in rows if r["selected"]), None)
    if best and best["estimate"]:
        e = best["estimate"]
        st.success("Winner %s: ETA %s = empty leg %ss + loaded leg %ss + handling %ss  (payload coefficient %s, "
                   "effective loaded speed %s m/s)" % (best["robot_id"], fmt_seconds(e["total_s"]), e["empty_leg_s"],
                                                       e["loaded_leg_s"], e["handling_s"], e["payload_coeff"],
                                                       e["effective_speed_mps"]))
    with st.expander("How the engine decides"):
        pr = res["params"]
        st.markdown(
            "1. **Availability** - Charging / Offline / Maintenance / busy units are filtered out.\n"
            "2. **Capacity check** - `wt <= Capacity`, otherwise the unit is dropped from the pool.\n"
            "3. **Domain battery floor** - Emergency 15 %, Medical 30 %, Dynamic 20 % (editable).\n"
            "4. **Route** - A* on the live graph; blocked corridors are excluded.\n"
            "5. **Time** - `speed = base_speed x domain multiplier`; `empty leg = d_pickup / speed`; "
            "`loaded leg = d_delivery x (1 + {alpha:.2f} x wt/Capacity) / speed`; `+ {handling:.0f} s handling`.\n"
            "6. **Rank** - Emergency: fastest ETA. Medical: ETA x (1+utilisation) x battery penalty. "
            "Dynamic (Set A): weighted blend of ETA, battery and load, shifting to speed when the queue grows.\n"
            "7. **Reserve** - the winner's window is written to its timeline and it is marked Active until it ends."
            .format(alpha=pr["payload_alpha"], handling=pr["handling_seconds"]))


def page_deliveries(org_id):
    st.subheader("Deliveries")
    locs = [l["location_name"] for l in (load("/api/locations/") or [])]
    supplies = load("/api/supplies/") or []
    domains = [d for d in (load("/api/domains/") or []) if d["is_active"]]
    orgs = org_options()
    with st.expander("Create delivery (task request)", expanded=True):
        with st.form("new_delivery"):
            c = st.columns(4)
            s_map = {"%s - %s" % (s["supply_id"], s["supply_name"]): s["supply_id"] for s in supplies}
            supply = c[0].selectbox("Supply", list(s_map.keys()) or ["-"])
            src = c[1].selectbox("Pickup", locs, index=0 if locs else None)
            dst = c[2].selectbox("Destination", locs, index=min(3, len(locs) - 1) if locs else None)
            priority = c[3].selectbox("Priority", ["Critical", "High", "Medium", "Low"], index=2)
            c2 = st.columns(4)
            wt = c2[0].number_input("wt - weight (kg)", min_value=0.1, max_value=100.0, value=1.0, step=0.5)
            qty = c2[1].number_input("Quantity", min_value=1, value=1, step=1)
            o_ids = [o["org_id"] for o in orgs if o["is_active"]]
            org = c2[2].selectbox("Organization", o_ids, index=o_ids.index(org_id) if org_id in o_ids else 0)
            d_map = {"Auto (by priority)": None}
            d_map.update({"%s [%s]" % (d["domain_name"], d["domain_id"]): d["domain_id"] for d in domains})
            dom = c2[3].selectbox("Domain", list(d_map.keys()))
            if st.form_submit_button("Create delivery", type="primary"):
                res = safe(api.post, "/api/deliveries/", {
                    "supply_id": s_map.get(supply), "source": src, "destination": dst, "weight_kg": wt,
                    "quantity": int(qty), "priority": priority, "org_id": org, "domain_id": d_map[dom]})
                if res is not None:
                    d = res["delivery"]
                    msg = "Created %s." % d["delivery_id"]
                    if d["delivery_status"] == "In Transit":
                        msg += " Robo auto mode assigned %s (ETA %s)." % (d["assigned_robot"], fmt_seconds(d["est_duration_seconds"]))
                    elif res.get("auto_schedule"):
                        msg += " Could not auto-schedule: %s" % res["auto_schedule"].get("reason")
                    flash("success", msg)
                    st.rerun()

    rows = load("/api/deliveries/", {"org_id": org_id} if org_id else None) or []
    f = st.selectbox("Filter by status", ["All", "Pending", "In Transit", "Delivered", "Cancelled"])
    shown = [r for r in rows if f == "All" or r["delivery_status"] == f]
    table(shown, ["delivery_id", "org_id", "priority", "delivery_status", "source", "destination", "weight_kg",
                  "assigned_robot", "domain_id", "algorithm_used", "route_distance_m", "est_duration_seconds",
                  "seconds_remaining", "schedule_mode", "route_path", "schedule_note"],
          {"weight_kg": "wt kg", "delivery_status": "status", "route_distance_m": "distance m",
           "est_duration_seconds": "ETA s", "seconds_remaining": "remaining s", "schedule_mode": "mode"})

    st.markdown("**Actions**")
    act = [r for r in rows if r["delivery_status"] in ("Pending", "In Transit")]
    if act:
        c = st.columns([3, 1, 1])
        key = c[0].selectbox("Delivery", ["%s (%s)" % (r["delivery_id"], r["delivery_status"]) for r in act])
        did = key.split(" ")[0]
        if c[1].button("Complete now"):
            if safe(api.post, "/api/deliveries/%s/complete" % did) is not None:
                flash("success", "%s delivered." % did)
                st.rerun()
        if c[2].button("Cancel"):
            if safe(api.post, "/api/deliveries/%s/cancel" % did) is not None:
                flash("warning", "%s cancelled." % did)
                st.rerun()


def page_fleet(org_id):
    st.subheader("Fleet (multi-tenant)")
    orgs = org_options()
    summary = load("/api/fleet/summary", {"org_id": org_id} if org_id else None)
    if summary:
        c = st.columns(4)
        c[0].metric("No. of Robots", summary["no_of_robots"])
        c[1].metric("Available", summary["available"])
        c[2].metric("Total capacity", "%s kg" % summary["total_capacity_kg"])
        c[3].metric("Largest unit", "%s kg" % summary["max_unit_capacity_kg"])
    robots = load("/api/robots/", {"org_id": org_id} if org_id else None) or []
    table(robots, ["robot_id", "org_id", "robot_type", "robot_status", "is_available", "battery_percentage",
                   "load_capacity_kg", "base_speed_mps", "current_location_name", "current_delivery"],
          {"robot_status": "status", "is_available": "available", "battery_percentage": "battery %",
           "load_capacity_kg": "capacity kg", "base_speed_mps": "speed m/s", "current_location_name": "location"})

    locs = [l["location_name"] for l in (load("/api/locations/") or [])]
    left, right = st.columns(2)
    with left:
        st.markdown("**Add a robot / drone node**")
        with st.form("add_robot"):
            o_ids = [o["org_id"] for o in orgs if o["is_active"]]
            org = st.selectbox("Organization", o_ids, index=o_ids.index(org_id) if org_id in o_ids else 0)
            c = st.columns(2)
            rtype = c[0].selectbox("Type", ["Robot", "Drone"])
            rid = c[1].text_input("Robot ID (blank = auto)")
            c = st.columns(3)
            cap = c[0].number_input("Capacity (kg)", min_value=0.5, max_value=500.0, value=10.0, step=0.5)
            speed = c[1].number_input("Base speed (m/s)", min_value=0.1, max_value=30.0, value=1.5, step=0.1)
            bat = c[2].number_input("Battery %", min_value=0, max_value=100, value=100, step=5)
            loc = st.selectbox("Start location", locs, index=0 if locs else None)
            if st.form_submit_button("Add node", type="primary"):
                res = safe(api.post, "/api/fleet/robots", {
                    "org_id": org, "robot_type": rtype, "robot_id": rid.strip() or None,
                    "load_capacity_kg": cap, "base_speed_mps": speed, "battery_percentage": int(bat),
                    "current_location": loc})
                if res is not None:
                    flash("success", "Added %s to %s." % (res["robot_id"], res["org_id"]))
                    st.rerun()
    with right:
        st.markdown("**Remove or update a node**")
        if robots:
            ids = [r["robot_id"] for r in robots]
            pick = st.selectbox("Robot", ids, key="fleet_pick")
            force = st.checkbox("Force (cancel its running task and re-queue the delivery)")
            if st.button("Remove node"):
                res = safe(api.delete, "/api/fleet/robots/%s" % pick, {"force": str(force).lower()})
                if res is not None:
                    flash("warning", "Removed %s%s." % (pick, " - re-queued %s" % res["requeued_delivery"]
                                                        if res.get("requeued_delivery") else ""))
                    st.rerun()
            c = st.columns(2)
            new_status = c[0].selectbox("Set status", ["Available", "Charging", "Offline", "Maintenance"])
            new_bat = c[1].number_input("Set battery %", min_value=0, max_value=100, value=100, step=5)
            if st.button("Apply update"):
                res = safe(api.put, "/api/fleet/robots/%s" % pick,
                           {"robot_status": new_status, "battery_percentage": int(new_bat)})
                if res is not None:
                    flash("success", "%s updated." % pick)
                    st.rerun()


def page_orgs():
    st.subheader("Organization Master")
    orgs = org_options()
    table(orgs, ["org_id", "org_name", "org_type", "contact_email", "is_active", "robot_count",
                 "available_count", "delivery_count", "created_at"],
          {"robot_count": "no. of robots", "available_count": "available", "delivery_count": "deliveries"})
    left, right = st.columns(2)
    with left:
        with st.form("new_org"):
            st.markdown("**Register organization**")
            oid = st.text_input("Custom ID (3-20 chars, e.g. ORG-003)")
            name = st.text_input("Name")
            typ = st.selectbox("Type", ["Hospital", "Clinic", "Laboratory", "Pharmacy Network"])
            mail = st.text_input("Contact email")
            if st.form_submit_button("Create", type="primary"):
                res = safe(api.post, "/api/organizations/", {"org_id": oid.strip(), "org_name": name.strip(),
                                                              "org_type": typ, "contact_email": mail or None})
                if res is not None:
                    flash("success", "Organization %s created." % res["org_id"])
                    st.rerun()
    with right:
        if orgs:
            st.markdown("**Delete organization** (must have no robots or deliveries)")
            pick = st.selectbox("Organization", [o["org_id"] for o in orgs], key="org_del")
            if st.button("Delete"):
                if safe(api.delete, "/api/organizations/%s" % pick) is not None:
                    flash("warning", "%s deleted." % pick)
                    st.rerun()


def page_domains(org_id):
    st.subheader("Domain Configurations")
    st.caption("Functional routing classes: Emergency, Medical and Dynamic (Set A).")
    domains = load("/api/domains/") or []
    flat = []
    for d in domains:
        cfg = d["config"] or {}
        flat.append({"domain_id": d["domain_id"], "name": d["domain_name"], "routing_class": d["routing_class"],
                     "option_set": d["option_set"] or "-", "speed x": cfg.get("speed_multiplier"),
                     "min battery %": cfg.get("min_battery"), "active": d["is_active"],
                     "names refreshed": d["names_refreshed_at"] or "-"})
    table(flat, ["domain_id", "name", "routing_class", "option_set", "speed x", "min battery %", "active",
                 "names refreshed"])

    st.markdown("**Refresh domain names**")
    st.caption("Regenerates every domain name from its template and the Organization Master (or apply custom names).")
    orgs = org_options()
    o_ids = [o["org_id"] for o in orgs]
    c = st.columns([2, 1])
    target = c[0].selectbox("Organization for naming", o_ids, index=o_ids.index(org_id) if org_id in o_ids else 0,
                            key="dom_org") if o_ids else None
    if c[1].button("Refresh domain names", type="primary"):
        res = safe(api.post, "/api/domains/refresh-names", {"org_id": target})
        if res is not None:
            flash("success", "Names refreshed: " + "; ".join("%s -> %s" % (x["domain_id"], x["new_name"])
                                                            for x in res["domains"]))
            st.rerun()

    if domains:
        st.markdown("**Edit configuration**")
        pick = st.selectbox("Domain", [d["domain_id"] for d in domains], key="dom_pick")
        current = next(d for d in domains if d["domain_id"] == pick)
        text = st.text_area("Config (JSON)", json.dumps(current["config"], indent=2), height=220,
                            key="cfg_%s" % pick)
        if st.button("Save configuration"):
            try:
                cfg = json.loads(text)
            except ValueError as exc:
                st.error("Invalid JSON: %s" % exc)
            else:
                if safe(api.put, "/api/domains/%s" % pick, {"config": cfg}) is not None:
                    flash("success", "%s saved." % pick)
                    st.rerun()


def page_routes():
    st.subheader("Route Optimizer")
    locs = [l["location_name"] for l in (load("/api/locations/") or [])]
    if not locs:
        return
    c = st.columns(2)
    src = c[0].selectbox("Source", locs)
    dst = c[1].selectbox("Destination", locs, index=min(3, len(locs) - 1))
    if st.button("Compare Dijkstra vs A*", type="primary"):
        if src == dst:
            st.warning("Choose different locations.")
        else:
            st.session_state["route_cmp"] = safe(api.post, "/api/routes/compare",
                                                 {"source": src, "destination": dst})
    cmp_ = st.session_state.get("route_cmp")
    if cmp_:
        rows = []
        for key in ("dijkstra", "astar"):
            r = cmp_[key]
            rows.append({"algorithm": r["algorithm"], "distance m": r["distance_meters"],
                         "nodes explored": r["nodes_explored"], "time ms": r["execution_ms"],
                         "path": " -> ".join(p["location_name"] for p in r["path"])})
        show_df(pd.DataFrame(rows))
        st.success("Both algorithms return the optimal distance (%s m); A* explores fewer nodes."
                   % cmp_["astar"]["distance_meters"] if cmp_["same_distance"]
                   else "Distances differ - check the graph.")
        if px is not None:
            fig = px.bar(pd.DataFrame(rows), x="algorithm", y="nodes explored", color="algorithm", text="nodes explored")
            fig.update_layout(height=260, margin=dict(l=10, r=10, t=10, b=10), showlegend=False)
            show_chart(fig)

    st.markdown("#### Corridors - block one to force an alternative route")
    edges = load("/api/routes/edges") or []
    table(edges, ["source", "destination", "distance_meters", "edge_type", "is_blocked"],
          {"distance_meters": "distance m", "is_blocked": "blocked"})
    if edges:
        labels = {"%s <-> %s%s" % (e["source"], e["destination"], "  [BLOCKED]" if e["is_blocked"] else ""): e
                  for e in edges}
        pick = labels[st.selectbox("Corridor", list(labels.keys()))]
        c = st.columns(2)
        if c[0].button("Block corridor"):
            if safe(api.put, "/api/routes/edges/block", {"source": pick["source"], "destination": pick["destination"],
                                                        "blocked": True}) is not None:
                flash("warning", "Blocked %s <-> %s. Re-run the comparison to see the alternative route."
                      % (pick["source"], pick["destination"]))
                st.rerun()
        if c[1].button("Unblock corridor"):
            if safe(api.put, "/api/routes/edges/block", {"source": pick["source"], "destination": pick["destination"],
                                                        "blocked": False}) is not None:
                flash("success", "Corridor reopened.")
                st.rerun()


def page_audit():
    st.subheader("Audit Log (timestamped actions)")
    c = st.columns(3)
    etype = c[0].selectbox("Entity", ["All", "delivery", "robot", "organization", "domain", "route", "system"])
    limit = c[1].selectbox("Rows", [50, 100, 250, 500], index=1)
    params = {"limit": limit}
    if etype != "All":
        params["entity_type"] = etype
    rows = load("/api/audit/", params) or []
    for r in rows:
        r["details"] = json.dumps(r["details"]) if r.get("details") else ""
    table(rows, ["logged_at", "actor", "entity_type", "entity_id", "action", "details"])


# -------------------------------------------------------------------- main
def main():
    st.title("🏥 Med-Supply PathFinder")
    st.caption("Hospital supply delivery - route optimisation, fleet allocation and Robo Mode")

    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Module", PAGES)
    orgs = org_options()
    org_id = None
    if orgs:
        choices = ["All"] + [o["org_id"] for o in orgs]
        label = {o["org_id"]: "%s - %s" % (o["org_id"], o["org_name"]) for o in orgs}
        pick = st.sidebar.selectbox("Organization", choices, format_func=lambda x: label.get(x, "All organizations"),
                                    index=1 if len(choices) > 1 else 0)
        org_id = None if pick == "All" else pick
    auto = st.sidebar.checkbox("Auto-refresh every 5 s", value=False)
    st.sidebar.divider()
    st.sidebar.caption("Streamlit -> FastAPI -> PostgreSQL")

    show_flash()
    if page == "Dashboard":
        page_dashboard(org_id)
    elif page == "Robo Mode":
        page_robo(org_id)
    elif page == "Decision Matrix":
        page_matrix(org_id if org_id else (orgs[0]["org_id"] if orgs else None))
    elif page == "Deliveries":
        page_deliveries(org_id)
    elif page == "Fleet":
        page_fleet(org_id)
    elif page == "Organizations":
        page_orgs()
    elif page == "Domains":
        page_domains(org_id)
    elif page == "Route Optimizer":
        page_routes()
    elif page == "Audit Log":
        page_audit()

    if auto:
        time.sleep(5)
        st.rerun()


main()
