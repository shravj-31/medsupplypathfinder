"""Thin client used by the Streamlit UI.  The UI never touches PostgreSQL:
Streamlit -> FastAPI -> PostgreSQL."""
import os

import requests

BASE_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000")


class ApiError(Exception):
    """Raised with a human readable message when the API returns an error."""


def request(method, endpoint, params=None, json=None):
    try:
        response = requests.request(method, BASE_URL + endpoint, params=params, json=json, timeout=30)
    except requests.exceptions.RequestException as exc:
        raise ApiError("Cannot reach the API at %s (%s). Is the backend running?" % (BASE_URL, exc.__class__.__name__))
    if not response.ok:
        try:
            detail = response.json().get("detail", response.text)
        except ValueError:
            detail = response.text
        if isinstance(detail, list):                       # pydantic validation errors
            detail = "; ".join("%s: %s" % (".".join(str(x) for x in d.get("loc", [])[1:]), d.get("msg"))
                               for d in detail)
        raise ApiError(str(detail))
    return response.json()


# ---- original helpers (kept so older code keeps working) ----------------
def get_data(endpoint: str, params=None):
    return request("GET", endpoint, params=params)


def calculate_route(source: str, destination: str, algorithm: str):
    return request("POST", "/api/routes/calculate",
                   json={"source": source, "destination": destination, "algorithm": algorithm})


# ---- new helpers -----------------------------------------------------------
def post(endpoint, payload=None):
    return request("POST", endpoint, json=payload or {})


def put(endpoint, payload=None):
    return request("PUT", endpoint, json=payload or {})


def delete(endpoint, params=None):
    return request("DELETE", endpoint, params=params)
