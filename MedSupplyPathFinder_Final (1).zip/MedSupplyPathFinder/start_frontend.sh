#!/usr/bin/env bash
cd "$(dirname "$0")"; [ -d venv ] && . venv/bin/activate
python -m streamlit run frontend/app.py
