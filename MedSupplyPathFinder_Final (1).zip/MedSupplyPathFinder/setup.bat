@echo off
REM One-time setup: virtual env + packages + database
cd /d %~dp0
if not exist venv (python -m venv venv)
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts\init_db.py
echo.
echo Setup finished. Now run start_backend.bat and start_frontend.bat (two windows).
pause
